<?php
    defined('BASEPATH') OR exit('URL inválido');
?>

<div class="contenitore m-top-20"><!-- Contenitore della notizia e della colonna vicina-->
    <h2 class="tit-principale">Medicina</h2>
    
        <div class="colon-7 m-top-10"><!--Colonna sin -->
            <?php foreach($med as $m): ?>
            <div id="contenitore-articolo-wrapper">
                <div class="articolo-wrapper "><!--articolo che deve contenere info piu piccole -->
                    <?php  $id = $m['id'] ?>
                    <?php  $url_slug = $m['url_slug'] ?>
                    <a class="a-leia " href="<?php echo site_url("blog/artigo/$id/$url_slug") ?>">
                        <img src="<?php echo base_url('assets/foto/'.$m['foto']) ?>" alt="">  
                    </a>
                </div>
                <div class="descricao-wrapper "><!--Descricao h - p -->
                    <h4><?php echo $m['titulo'] ?></h4>
                    <p class=""> <?php echo $m['descricao'] ?>
                        <a class="a-leia " href="<?php echo site_url("blog/artigo/$id/$url_slug") ?>">
                            <span><em> Leia mais &raquo</em></span> 
                        </a>
                    </p>
                </div>
            </div>
            <?php endforeach; ?>
        </div>
   
    
      

    <div class="colon-3 enf-hme"><!--Colonna dest -->
        <div class="row">
            <!--Immagine con link -->
            <div class="col-md-4 amazon_bordo">
                <a target="_blank"  href="https://www.amazon.com.br/gp/product/853880412X/ref=as_li_tl?ie=UTF8&camp=1789&creative=9325&creativeASIN=853880412X&linkCode=as2&tag=antonio1981-20&linkId=5be22c3e04e4471c92d10aa49e279f2e"><img border="0" src="//ws-na.amazon-adsystem.com/widgets/q?_encoding=UTF8&MarketPlace=BR&ASIN=853880412X&ServiceVersion=20070822&ID=AsinImage&WS=1&Format=_SL160_&tag=antonio1981-20" ></a><img src="//ir-br.amazon-adsystem.com/e/ir?t=antonio1981-20&l=am2&o=33&a=853880412X" width="1" height="1" border="0" alt="" style="border:none !important; margin:0px !important;" />
                    <img src="//ir-br.amazon-adsystem.com/e/ir?t=antonio1981-20&l=am2&o=33&a=8535287019" 
                    width="1" height="1" border="0" alt="" style="border:none !important; margin:0px !important;" />
            </div>
            <!--Titolo con descrizione e prezzo -->
            <div class="col-md-8">
                <a target="_blank" href="https://www.amazon.com.br/gp/product/853880412X/ref=as_li_tl?ie=UTF8&camp=1789&creative=9325&creativeASIN=853880412X&linkCode=as2&tag=antonio1981-20&linkId=5be22c3e04e4471c92d10aa49e279f2e">Prevenção e Tratamento de úlcera por Pressão</a><img src="//ir-br.amazon-adsystem.com/e/ir?t=antonio1981-20&l=am2&o=33&a=8535287019" width="1" height="1" border="0" alt="" style="border:none !important; margin:0px !important;" />
                <p>"Prevenção e Tratamento de Úlcera por Pressão" é obra cuidadosamente elaborada,
                 cujas editoras conseguiram unificar os conhecimentos especializados - científicos e 
                 tecnológicos - de profissionais de renome nacional e internacional em sua área de atuação. 
                  </p>
                <p>R$ 138,06</p>
            </div>
        </div>
    </div>
</div>