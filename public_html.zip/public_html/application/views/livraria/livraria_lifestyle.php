<?php
    defined('BASEPATH') OR exit('URL inválido');
?>
<div class="container m-top-30"><!-- Contenitore della notizia e della colonna vicina-->
    <div class="row">
        <div class="col-sm-8 "><!--Colonna sin -->
            
                <?php foreach($livlifestyle as $row) :?>
                    <div class="row">
                    <!-- 000000000000000000000000000000000000000000000000 -->
                    <li class="media m-bot-10 mr-3">
                        <?php  $id = $row->id ?>
                        <?php  $url_slug =  $row->url_slug ?>
                        <a class="" href="<?php echo site_url("blog/mostra_livro/$id/$url_slug")?>">
                            <img class="mr-3" src="<?php echo base_url('assets/livros/'.$row->foto) ?>" alt="Generic placeholder image">
                        </a>    
                        <div class="media-body">
                            <a class="" href="<?php echo site_url("blog/mostra_livro/$id/$url_slug")?>">
                                <h5 class="mt-0 mb-1"><?php echo $row->titulo ?></h5>
                            </a>
                            <p class="mt-0 mb-1"><?php echo $row->autor ?></p>
                            <p class="mt-0 mb-1"><span class="badge badge-warning"><?php echo $row->preco ?></span> </p>
                        </div>  
                    </li>
                    </div>
                <?php endforeach; ?>
           
            <div class="row">
                <div class="paginazione">
                    <nav aria-label="Page navigation example">
                        <ul class="pagination">
                            <?php  echo $pagination;  ?>
                        </ul>
                    </nav>  
                </div> 
            </div>
        </div>

        <!--Colonna dest -->
        <div class="col-sm-4">
        </div>
    </div>
</div>