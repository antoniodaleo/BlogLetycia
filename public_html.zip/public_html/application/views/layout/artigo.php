<?php
    defined('BASEPATH') OR exit('URL inválido');

    // <p>Id = php echo $p_chegando['id']</p> 
?>

<div class="contenitore m-top-30">
    <div class="colon-7">
        <?php foreach($p as $p_chegando): ?>
            <p id="p-data" class="">LetyciaLobato flash, <?php echo $p_chegando['data_post']?>  </p>     
            <h3 class="m-top-10"><?php echo $p_chegando['titulo']?>  </h3> 
            <p id="p-descricao"><?php echo $p_chegando['descricao']?>  </p>
            <hr> 
            <div class="contenitore-social">
                <ul id="icons">
                    <li class="">
                        <a target="_blank" href="https://www.facebook.com/sharer/sharer.php?u=https%3A%2F%2Fdevelopers.facebook.com%2Fdocs%2Fplugins%2F&amp;src=sdkpreparse" >
                            <i class="fab fa-facebook-square"></i></a>
                        </a>
                    </li>
                    <li>
                        <a href="https://twitter.com/share?ref_src=twsrc%5Etfw" 
                            target="_blank"><i class="fab fa-twitter-square"></i>
                        </a>
                        <script async src="https://platform.twitter.com/widgets.js" charset="utf-8"></script>
                    </li>
                </ul>
            </div>
            <img id="img-art" class="card-img" src="<?php echo base_url('assets/foto/'.$p_chegando['foto']) ?>" alt="Card image">
            <br>
            <p><?php echo $p_chegando['testo']?>

            </p>
        <?php endforeach; ?>
        <div class="card" id="email" style="width: 100%;">
            <div class="card-body">
                <h5 class="card-title"><i class="fas fa-at"> </i>Email</h5>
                    <p class="card-text">Fica sempre atualizado, cadastra a sua email</p>

                    <form action="<?php echo site_url('geral/add_email')?>" method="post">
                        <input type="text" class="form-control" name="text-email"
                        placeholder="exemplo@email.com" required>
                        <button class="btn btn-primary m-top-10" type="submit">Enviar</button>
                    </form>
            </div>
        </div>
    </div>

    <div class="colon-3">
        
                
                <div class="card" style="width: 100%;">
                    <div class="card-body">
                        <h5 class="card-title"><i class="fas fa-at"> </i>Email</h5>
                        <p class="card-text">Fica sempre atualizado, cadastra a sua email</p>

                        <form action="<?php echo site_url('geral/add_email')?>" method="post">
                            <input type="text" class="form-control" name="text-email"
                            placeholder="exemplo@email.com" required>
                            <button class="btn btn-primary m-top-10" type="submit">Enviar</button>
                        </form>
                    </div>
                </div>
                <div class="fb-page m-top-20 " data-href="https://www.facebook.com/letycialobatofanpage" data-small-header="true" data-adapt-container-width="true" data-hide-cover="false" data-show-facepile="false"><blockquote cite="https://www.facebook.com/letycialobatofanpage" class="fb-xfbml-parse-ignore"><a href="https://www.facebook.com/letycialobatofanpage">Letycialobato</a></blockquote></div>            </div>
        
</div>

<hr class="break">