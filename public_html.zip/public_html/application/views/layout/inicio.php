<?php
    defined('BASEPATH') OR exit('URL inválido');
?>

<!DOCTYPE html>
<html lang="pt">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>letycialobato.com.br - Enfermagem, Medicina, Nutrição</title>
     <!--SEO -->
    <meta name="description" content="blog de enfermagem, medicina, saude, nutrição, psicologia">
    <meta name="keywords" content="enfermagem,saude,motivação,auto-ajuda,psicologia, livros
        nutrição, amazon"/>
    <meta name="author" content="Anthonio Daleo - Developper, antoniodaleo@outlook.com"/>

    
    <!--Bootstrap Framework -->  
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
    <!--FONT AWESOME -->  
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.7.2/css/all.css" integrity="sha384-fnmOCqbTlWIlj8LyTjo7mOUStjsKC4pOpQbqyi7RrhN7udi9RwhKkMHpvLbHG9Sr" crossorigin="anonymous">    
    <link href="https://fonts.googleapis.com/css?family=Abril+Fatface|Cinzel" rel="stylesheet"> 
    <!--Foglio di stile -->  
    <link rel="stylesheet" href="<?php echo base_url('assets/css/main.css') ?>">
    
    <!-- ADSENSE -->  
    <script async custom-element="amp-auto-ads"
        src="https://cdn.ampproject.org/v0/amp-auto-ads-0.1.js">
    </script>
    

    <!-- Global site tag (gtag.js) - Google Analytics -->
    <script async src="https://www.googletagmanager.com/gtag/js?id=UA-130114651-1"></script>
    <script>
    window.dataLayer = window.dataLayer || [];
    function gtag(){dataLayer.push(arguments);}
    gtag('js', new Date());
    gtag('config', 'UA-130114651-1');
    </script>


    
</head>
<body>

    <div class="container">
    <div id="fb-root"></div>
        <script async defer crossorigin="anonymous" src="https://connect.facebook.net/pt_PT/sdk.js#xfbml=1&version=v3.3"></script>

