<?php
    defined('BASEPATH') OR exit('URL inválido');

    class Blog extends CI_Controller{
        public function index(){
            $this->load->view('layout/inicio.php'); 
            $this->load->view('layout/nav_top.php'); 
            $this->load->view('layout/logo.php');
            $this->load->view('layout/nav.php'); 
            //Carichiamo il model
            $this->load->model('post'); 
            $this->load->model('livros'); 
            //Carichiamo le notizie
            $dados['pol']=$this->post->tudoPolitica();
            $dados['news']= $this->post->ultimo_artigo(); 
            $dados['enfuno']=$this->post->unoEnfermagem();
            $dados['enf']=$this->post->tudoEnfermagem();
            $dados['meduno']=$this->post->unoMedicina();
            $dados['med']=$this->post->tudoMedicina(); 
            $dados['psi'] = $this->post->tudoPsicologia(); 
            $dados['lifuno'] = $this->post->unoLifestyle_notizia();
            $dados['lif'] = $this->post->tudoLifestyle_notizia();
            $dados['nut'] = $this->post->tudoAlimentacao(); 
            $dados['pan'] = $this->post->tudoPanorama(); 
            //Carichiamo i video
            $dados['vid'] = $this->post->video(); 
            $dados['vid2'] = $this->post->video_2(); 
            $dados['livpro'] = $this->livros->mostra_libri_sulla_home(); 
            $this->load->view('layout/home_.php',  $dados);

            //-----------------------------------------------------------
            $this->load->view('layout/fim.php');
        }    

        //=============Paginação Pagina principal enfermagem
        public function enfermagem(){
            $this->load->library('pagination');
            $this->load->model('post','p');
            //$config['base_url'] = "http://www.letycialobato.com.br/index.php/blog/enfermagem";
            $config['base_url'] = "http://localhost/public_html/blog/enfermagem";
            $config['uri_segement'] = 3; 
            $config['per_page'] = 10; 
            
            //Pagination Style
            $config['full_tag_open']    = '<div class="pagging text-center"><nav><ul class="pagination">';
            $config['full_tag_close']   = '</ul></nav></div>';
            $config['num_tag_open']     = '<li class="page-item"><span class="page-link">';
            $config['num_tag_close']    = '</span></li>';
            $config['cur_tag_open']     = '<li class="page-item active"><span class="page-link">';
            $config['cur_tag_close']    = '<span class="sr-only">(current)</span></span></li>';
            $config['next_tag_open']    = '<li class="page-item"><span class="page-link">';
            $config['next_tag_close']  = '<span aria-hidden="true"></span></span></li>';
            // $config['next_tag_close']  = '<span aria-hidden="true">&raquo;</span></span></li>';
            $config['prev_tag_open']    = '<li class="page-item"><span class="page-link">';
            $config['prev_tag_close']  = '</span></li>';
            $config['first_tag_open']   = '<li class="page-item"><span class="page-link">';
            $config['first_tag_close'] = '</span></li>';
            $config['last_tag_open']    = '<li class="page-item"><span class="page-link">';
            $config['last_tag_close']  = '</span></li>';

            $page = $this->uri->segment(3,0); 
           
            $this->load->model('livros');
            $this->load->model('post','p');
            $this->load->model('comentarios','com');
            $data['livpro'] = $this->livros->mostra_libri_sulla_home(); 
            $data['vid'] = $this->p->video(); 
               

             
            $data['art'] = $this->p->get_post_enfermagem($config['per_page'], $page); 
            $config['total_rows'] = $this->p->get_qtd_post(); 
            $this->pagination->initialize($config); 
            $data['pagination'] = $this->pagination->create_links();
            
            $this->load->view('layout/inicio.php'); 
            $this->load->view('layout/nav_top.php'); 
            $this->load->view('layout/logo.php');
            $this->load->view('layout/nav.php'); 
            $this->load->view('layout/enfermagem_home.php', $data);
            $this->load->view('layout/fim.php');
        }
        //Pagina principal politica
        public function news(){
            $this->load->library('pagination');
            $this->load->model('post','p');
            $config['base_url'] = "http://localhost/public_html/blog/news";
            $config['uri_segement'] = 3; 
            $config['per_page'] = 10; 
            
            //Pagination Style
            $config['full_tag_open']    = '<div class="pagging text-center"><nav><ul class="pagination">';
            $config['full_tag_close']   = '</ul></nav></div>';
            $config['num_tag_open']     = '<li class="page-item"><span class="page-link">';
            $config['num_tag_close']    = '</span></li>';
            $config['cur_tag_open']     = '<li class="page-item active"><span class="page-link">';
            $config['cur_tag_close']    = '<span class="sr-only">(current)</span></span></li>';
            $config['next_tag_open']    = '<li class="page-item"><span class="page-link">';
            $config['next_tag_close']  = '<span aria-hidden="true"></span></span></li>';
            // $config['next_tag_close']  = '<span aria-hidden="true">&raquo;</span></span></li>';
            $config['prev_tag_open']    = '<li class="page-item"><span class="page-link">';
            $config['prev_tag_close']  = '</span></li>';
            $config['first_tag_open']   = '<li class="page-item"><span class="page-link">';
            $config['first_tag_close'] = '</span></li>';
            $config['last_tag_open']    = '<li class="page-item"><span class="page-link">';
            $config['last_tag_close']  = '</span></li>';

            $page = $this->uri->segment(3,0); 
            $this->load->model('livros');
            $this->load->model('post','p');
            $this->load->model('comentarios','com');
            $data['livpro'] = $this->livros->mostra_libri_sulla_home(); 
            $data['vid'] = $this->p->video(); 
            $data['art'] = $this->p->get_post_news($config['per_page'], $page); 
            $config['total_rows'] = $this->p->get_qtd_post_news(); 
            $this->pagination->initialize($config); 
            $data['pagination'] = $this->pagination->create_links();
            
            $this->load->view('layout/inicio.php'); 
            $this->load->view('layout/nav_top.php'); 
            $this->load->view('layout/logo.php');
            $this->load->view('layout/nav.php'); 
            $this->load->view('layout/news_home.php', $data);
            $this->load->view('layout/fim.php');
        }
        //Pagina principal reportage
        public function panorama(){
            $this->load->library('pagination');
            $this->load->model('post','p');
            $config['base_url'] = "http://localhost/public_html/blog/panorama";
            $config['uri_segement'] = 3; 
            $config['per_page'] = 10; 
            
            //Pagination Style
            $config['full_tag_open']    = '<div class="pagging text-center"><nav><ul class="pagination">';
            $config['full_tag_close']   = '</ul></nav></div>';
            $config['num_tag_open']     = '<li class="page-item"><span class="page-link">';
            $config['num_tag_close']    = '</span></li>';
            $config['cur_tag_open']     = '<li class="page-item active"><span class="page-link">';
            $config['cur_tag_close']    = '<span class="sr-only">(current)</span></span></li>';
            $config['next_tag_open']    = '<li class="page-item"><span class="page-link">';
            $config['next_tag_close']  = '<span aria-hidden="true"></span></span></li>';
            // $config['next_tag_close']  = '<span aria-hidden="true">&raquo;</span></span></li>';
            $config['prev_tag_open']    = '<li class="page-item"><span class="page-link">';
            $config['prev_tag_close']  = '</span></li>';
            $config['first_tag_open']   = '<li class="page-item"><span class="page-link">';
            $config['first_tag_close'] = '</span></li>';
            $config['last_tag_open']    = '<li class="page-item"><span class="page-link">';
            $config['last_tag_close']  = '</span></li>';

            $page = $this->uri->segment(3,0); 

            $data['art'] = $this->p->get_post_panorama($config['per_page'], $page); 
            $config['total_rows'] = $this->p->get_qtd_post_pan(); 
            $this->pagination->initialize($config); 
            $data['pagination'] = $this->pagination->create_links();
            $this->load->model('livros');
            $this->load->model('post','p');
            $this->load->model('comentarios','com');
            $data['livpro'] = $this->livros->mostra_libri_sulla_home(); 
            $data['vid'] = $this->p->video(); 
            $this->load->view('layout/inicio.php'); 
            $this->load->view('layout/nav_top.php'); 
            $this->load->view('layout/logo.php');
            $this->load->view('layout/nav.php'); 
            $this->load->view('layout/panorama_home.php', $data);
            $this->load->view('layout/fim.php');
        }
        //Pagina principal medicina
         public function medicina(){
            $this->load->library('pagination');
            $this->load->model('post','p');
            $config['base_url'] = "http://localhost/public_html/blog/medicina";
            $config['uri_segement'] = 3; 
            $config['per_page'] = 10; 
            
            //Pagination Style
            $config['full_tag_open']    = '<div class="pagging text-center"><nav><ul class="pagination">';
            $config['full_tag_close']   = '</ul></nav></div>';
            $config['num_tag_open']     = '<li class="page-item"><span class="page-link">';
            $config['num_tag_close']    = '</span></li>';
            $config['cur_tag_open']     = '<li class="page-item active"><span class="page-link">';
            $config['cur_tag_close']    = '<span class="sr-only">(current)</span></span></li>';
            $config['next_tag_open']    = '<li class="page-item"><span class="page-link">';
            $config['next_tag_close']  = '<span aria-hidden="true"></span></span></li>';
            // $config['next_tag_close']  = '<span aria-hidden="true">&raquo;</span></span></li>';
            $config['prev_tag_open']    = '<li class="page-item"><span class="page-link">';
            $config['prev_tag_close']  = '</span></li>';
            $config['first_tag_open']   = '<li class="page-item"><span class="page-link">';
            $config['first_tag_close'] = '</span></li>';
            $config['last_tag_open']    = '<li class="page-item"><span class="page-link">';
            $config['last_tag_close']  = '</span></li>';

            $page = $this->uri->segment(3,0); 

            $data['art'] = $this->p->get_post_medicina($config['per_page'], $page); 
            $config['total_rows'] = $this->p->get_qtd_post_med(); 
            $this->pagination->initialize($config); 
            $data['pagination'] = $this->pagination->create_links();
            $this->load->model('livros');
            $this->load->model('post','p');
            $this->load->model('comentarios','com');
            $data['livpro'] = $this->livros->mostra_libri_sulla_home(); 
            $data['vid'] = $this->p->video(); 
            $this->load->view('layout/inicio.php'); 
            $this->load->view('layout/nav_top.php'); 
            $this->load->view('layout/logo.php');
            $this->load->view('layout/nav.php'); 
            $this->load->view('layout/medicina_home.php', $data);
            $this->load->view('layout/fim.php');
        } 
        //Pagina principal alimentaçao
        public function alimentacao(){
            $this->load->library('pagination');
            $this->load->model('post','p');
            $config['base_url'] = "http://localhost/public_html/blog/alimentacao";
            $config['uri_segement'] = 3; 
            $config['per_page'] = 10; 
            
            //Pagination Style
            $config['full_tag_open']    = '<div class="pagging text-center"><nav><ul class="pagination">';
            $config['full_tag_close']   = '</ul></nav></div>';
            $config['num_tag_open']     = '<li class="page-item"><span class="page-link">';
            $config['num_tag_close']    = '</span></li>';
            $config['cur_tag_open']     = '<li class="page-item active"><span class="page-link">';
            $config['cur_tag_close']    = '<span class="sr-only">(current)</span></span></li>';
            $config['next_tag_open']    = '<li class="page-item"><span class="page-link">';
            $config['next_tag_close']  = '<span aria-hidden="true"></span></span></li>';
            // $config['next_tag_close']  = '<span aria-hidden="true">&raquo;</span></span></li>';
            $config['prev_tag_open']    = '<li class="page-item"><span class="page-link">';
            $config['prev_tag_close']  = '</span></li>';
            $config['first_tag_open']   = '<li class="page-item"><span class="page-link">';
            $config['first_tag_close'] = '</span></li>';
            $config['last_tag_open']    = '<li class="page-item"><span class="page-link">';
            $config['last_tag_close']  = '</span></li>';

            $page = $this->uri->segment(3,0); 
            $this->load->model('livros');
            $this->load->model('post','p');
            $this->load->model('comentarios','com');
            $data['livpro'] = $this->livros->mostra_libri_sulla_home(); 
            $data['vid'] = $this->p->video(); 
            $data['art'] = $this->p->get_post_alimentacao($config['per_page'], $page); 
            $config['total_rows'] = $this->p->get_qtd_post_ali(); 
            $this->pagination->initialize($config); 
            $data['pagination'] = $this->pagination->create_links();
            
            $this->load->view('layout/inicio.php'); 
            $this->load->view('layout/nav_top.php'); 
            $this->load->view('layout/logo.php');
            $this->load->view('layout/nav.php'); 
            $this->load->view('layout/alimentacao_home.php', $data);
            $this->load->view('layout/fim.php');
        }
        //Pagina principal lifeStyle id=8
        public function lifestyle(){
            $this->load->library('pagination');
            $this->load->model('post','p');
            $config['base_url'] = "http://localhost/public_html/blog/lifestyle";
            $config['uri_segement'] = 3; 
            $config['per_page'] = 10; 
            
            //Pagination Style
            $config['full_tag_open']    = '<div class="pagging text-center"><nav><ul class="pagination">';
            $config['full_tag_close']   = '</ul></nav></div>';
            $config['num_tag_open']     = '<li class="page-item"><span class="page-link">';
            $config['num_tag_close']    = '</span></li>';
            $config['cur_tag_open']     = '<li class="page-item active"><span class="page-link">';
            $config['cur_tag_close']    = '<span class="sr-only">(current)</span></span></li>';
            $config['next_tag_open']    = '<li class="page-item"><span class="page-link">';
            $config['next_tag_close']  = '<span aria-hidden="true"></span></span></li>';
            // $config['next_tag_close']  = '<span aria-hidden="true">&raquo;</span></span></li>';
            $config['prev_tag_open']    = '<li class="page-item"><span class="page-link">';
            $config['prev_tag_close']  = '</span></li>';
            $config['first_tag_open']   = '<li class="page-item"><span class="page-link">';
            $config['first_tag_close'] = '</span></li>';
            $config['last_tag_open']    = '<li class="page-item"><span class="page-link">';
            $config['last_tag_close']  = '</span></li>';

            $page = $this->uri->segment(3,0); 

            $data['art'] = $this->p->get_post_lifestyle($config['per_page'], $page); 
            $config['total_rows'] = $this->p->get_qtd_post_lif(); 
            $this->pagination->initialize($config); 
            $data['pagination'] = $this->pagination->create_links();
            $this->load->model('livros');
            $this->load->model('post','p');
            $this->load->model('comentarios','com');
            $data['livpro'] = $this->livros->mostra_libri_sulla_home(); 
            $data['vid'] = $this->p->video(); 
            $this->load->view('layout/inicio.php'); 
            $this->load->view('layout/nav_top.php'); 
            $this->load->view('layout/logo.php');
            $this->load->view('layout/nav.php'); 
            $this->load->view('layout/lifestyle_home.php', $data);
            $this->load->view('layout/fim.php');


        }
        //Pagina principal psicologia id=9
        public function psicologia(){
            $this->load->library('pagination');
            $this->load->model('post','p');
            $config['base_url'] = "http://localhost/public_html/blog/psicologia";
            $config['uri_segement'] = 3; 
            $config['per_page'] = 10; 
            
            //Pagination Style
            $config['full_tag_open']    = '<div class="pagging text-center"><nav><ul class="pagination">';
            $config['full_tag_close']   = '</ul></nav></div>';
            $config['num_tag_open']     = '<li class="page-item"><span class="page-link">';
            $config['num_tag_close']    = '</span></li>';
            $config['cur_tag_open']     = '<li class="page-item active"><span class="page-link">';
            $config['cur_tag_close']    = '<span class="sr-only">(current)</span></span></li>';
            $config['next_tag_open']    = '<li class="page-item"><span class="page-link">';
            $config['next_tag_close']  = '<span aria-hidden="true"></span></span></li>';
            // $config['next_tag_close']  = '<span aria-hidden="true">&raquo;</span></span></li>';
            $config['prev_tag_open']    = '<li class="page-item"><span class="page-link">';
            $config['prev_tag_close']  = '</span></li>';
            $config['first_tag_open']   = '<li class="page-item"><span class="page-link">';
            $config['first_tag_close'] = '</span></li>';
            $config['last_tag_open']    = '<li class="page-item"><span class="page-link">';
            $config['last_tag_close']  = '</span></li>';

            $page = $this->uri->segment(3,0); 

            $data['art'] = $this->p->get_post_psicologia($config['per_page'], $page); 
            $config['total_rows'] = $this->p->get_qtd_post_psi(); 
            $this->pagination->initialize($config); 
            $data['pagination'] = $this->pagination->create_links();
            $this->load->model('livros');
            $this->load->model('post','p');
            $this->load->model('comentarios','com');
            $data['livpro'] = $this->livros->mostra_libri_sulla_home(); 
            $data['vid'] = $this->p->video(); 
            $this->load->view('layout/inicio.php'); 
            $this->load->view('layout/nav_top.php'); 
            $this->load->view('layout/logo.php');
            $this->load->view('layout/nav.php'); 
            $this->load->view('layout/psicologia_home.php', $data);
            $this->load->view('layout/fim.php');
        }
        //============================ Pagina Livraria Amazon
        public function livraria(){
            $this->load->view('layout/inicio.php'); 
            $this->load->view('layout/logo_livraria.php');
            $this->load->view('layout/nav_livraria.php'); 
            $this->load->model('livros','livro'); 
            $dados['enf'] =$this->livro->mostra_livro_enfermagem();
            $dados['enftre'] =$this->livro->mostra_livro_enfermagem_3();
            $dados['psi'] = $this->livro->mostra_livro_psicologia();
            $dados['nut'] = $this->livro->mostra_livro_nutricao();
            $dados['die'] = $this->livro->mostra_livro_dieta();
            $dados['aut'] = $this->livro->mostra_livro_autoajuda();
            $dados['med'] = $this->livro->mostra_livro_medicina();
            $dados['lifsty']=$this->livro->mostra_livro_lifestyle_2(); 
            $this->load->view('layout/livraria_home.php',$dados);
            $this->load->view('layout/fim.php');
        } 

        public function contatos(){
            $this->load->view('layout/inicio.php'); 
            $this->load->view('layout/nav_top.php'); 
            $this->load->view('layout/logo.php');
            $this->load->view('layout/nav.php'); 
            $this->load->view('layout/contatos_home.php');
            $this->load->view('layout/fim.php');
        }
        // Adicionar email
        public function add_email(){
            if($this->input->method()!== 'post'){
                
            }else{
                $this->load->model('email'); 
                $this->email->inserir_email(); 
                $this->load->view('layout/inicio.php'); 
                $this->load->view('layout/nav_top.php'); 
                $this->load->view('layout/logo.php');
                $this->load->view('layout/nav.php');
                $this->load->view('redacao/successo.php'); 
                $this->load->view('layout/fim.php');
            }
        }
        // Adicionar comentario
        public function add_comentario(){
            $this->load->model('comentarios');
            $this->comentarios->inserir_comentario();
            $this->load->model('email');
            $this->email->inserir_email(); 

            $this->load->view('layout/inicio.php'); 
            $this->load->view('layout/nav_top.php'); 
            $this->load->view('layout/logo.php');
            $this->load->view('layout/nav.php'); 
            $this->load->view('redacao/successo_com.php');
            $this->load->view('layout/fim.php');

        
           

        }

        // Pesquisa artigo per parola
        public function pesquisa(){
            if($this->input->method()!== 'post'){

            }else{
                $this->load->model('pesquisa'); 
                $dados['pesq']=  $this->pesquisa->pesquisa_artigo(); 
                $this->load->view('layout/inicio.php'); 
                $this->load->view('layout/nav_top.php'); 
                $this->load->view('layout/logo.php');
                $this->load->view('layout/nav.php');
                // Pagina in cui mi mostri tutti glia articoli che iniziano con il nome
                $this->load->view('layout/page_pesquisa.php',$dados);
                $this->load->view('layout/fim.php');
            }
        }
        // Pesquisa artigo per parola
        public function pesquisa_livro(){
            if($this->input->method()!== 'post'){

            }else{
                $this->load->model('pesquisa'); 
                $dados['liv']=  $this->pesquisa->pesquisa_livro();  
                $this->load->view('layout/inicio.php'); 
                $this->load->view('layout/logo_livraria.php');
                $this->load->view('layout/nav_livraria.php'); 
                // Pagina in cui mi mostri tutti glia articoli che iniziano con il nome
                $this->load->view('redacao/mostra_livro.php',$dados);
                $this->load->view('layout/fim.php');
            }
        }
        // Criar o artigo
        public function criar_artigo(){
            //Se nn é effettuato il post mi ritorni il formulario
            if($this->input->method()!== 'post'){
                $this->load->view('layout/inicio.php'); 
                $this->load->view('layout/nav_top.php'); 
                $this->load->view('layout/logo.php');
                $this->load->view('layout/nav.php'); 
                $this->load->model('Argumentos', 'arg');
                $dados['argomento'] = $this->arg->prendi_argomenti(); 
                $this->load->view('aplicativo/inserir_artigo.php',$dados);   
                $this->load->view('layout/fim.php');
                return;  
            }
              // Faz o upload da imagem dimensioni piu grandi
            // Define as propriedades da biblioteca 'upload'
            $config['upload_path'] = './assets/foto/' ;
            $config['allowed_types']= 'jpg|png';
            $config['max_size'] = 9999999;
            $config['max_width'] = 1024;
            $config['max_height'] = 1024 ;
            //============================================================================
            //Foto 0 Carichiamo la foto principale
            $ficheiro = $_FILES["ficheiro_foto"]["name"];
            $ficheiro_original_sem_extensao = pathinfo($ficheiro, PATHINFO_FILENAME); 
            $ficheiro_extensao =  pathinfo($ficheiro, PATHINFO_EXTENSION); 
            // Carrega o helper 
            $this->load->helper('nome_ficheiro'); 
            $nome_foto_final = definir_nome_ficheiro($ficheiro_original_sem_extensao, $ficheiro); 
            $config['file_name'] = $nome_foto_final; 
            // Carrega a biblioteca upload
            $this->load->library('upload', $config); 

    
            
            //===========================================Tenta fazer o upload da imagem
            if($this->upload->do_upload('ficheiro_foto')){
                // Guarda os dados na base de d
                $this->load->model('post','p'); 
                //guarda a informação na base de dados
                // Inserire l id dell argomento 
                $this->p->inserir_artigo($nome_foto_final); 

                $this->load->view('layout/inicio'); 
                $this->load->view('redacao/successo'); 
                $this->load->view('layout/fim'); 
            }else{
                //Ocorreu erro no carreg da fotografia
                $this->load->view('layout/inicio'); 
                $dados['erros'] = $this->upload->display_errors(); 
                $this->load->view('redacao/erro',$dados); 
                $this->load->view('layout/fim');

            }
             
        }
        // Mostra o artigo
        public function artigo($id){
            $this->load->view('layout/inicio.php'); 
            $this->load->view('layout/nav_top.php'); 
            $this->load->view('layout/logo.php');
            $this->load->view('layout/nav.php');

            $this->load->model('livros');
            $this->load->model('post','p');
            $this->load->model('comentarios','com');
            $dados['livpro'] = $this->livros->mostra_libri_sulla_home(); 
            $dados['news'] = $this->p->notizieflash();
            $dados['come']=$this->com->pega_comentarios_post($id);
            $dados['p'] = $this->p->select_artigo($id);  
            $dados['vid'] = $this->p->video(); 
            $dados['vid2'] = $this->p->video_2();     

            $this->load->view('redacao/artigo',$dados); 
            
            $this->load->view('layout/fim.php');
        }

        // Mostra o livro
        public function mostra_livro($id){
            $this->load->view('layout/inicio.php'); 
            $this->load->view('layout/logo_livraria.php');
            $this->load->view('layout/nav_livraria.php'); 
            $this->load->model('livros','livro');
            //Inseriamo tutte le ricerche dei libri
            $dados['liv'] = $this->livro->select_livro($id); 

            $this->load->view('redacao/mostra_livro',$dados); 
            $this->load->view('layout/fim.php');
        }

       
       
        
    }
?>