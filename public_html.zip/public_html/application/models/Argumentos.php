<?php
    defined('BASEPATH') OR exit('URL inválido');

    class Argumentos extends CI_Model{

        public function prendi_argomenti(){
           return $this->db->query('SELECT * FROM argumento')->result_array();
        }


        public function prendi_id_argumento($id){
            return $this->db->query('SELECT * FROM argumento WHERE id = $id')->result_array()[0];
         }

    }
?>