<?php
    defined('BASEPATH') OR exit('URL inválido');
    //<div class="col-sm-6 offset-3 col-8 offset-2">
?>

   
       <div class="container m-top-30 body">
          
           <div class="row">

               <div class="col-md-3 col-xs-12">
                   <div class="imgBx">
                       <img src="<?php echo base_url('assets/foto/antonio.jpg')?>" alt="">
                   </div>
                   <div class="details">
                       <h3>Antonio D'aleo <br> <span>Developer and Founder </span></h3>
                       <ul>
                           <li><a href="#"><i class="fab fa-facebook-f"></i></a> </li>
                           <li><a href="https://github.com/antoniodaleo" target="_blank" title="GitHub"><i class="fab fa-github"></i></a> </li>
                           <li><a href="www.linkedin.com/in/anthoniodaleo" target="_blank"><i class="fab fa-linkedin"></i></a> </li>
                       </ul>
                    </div>
               </div>
               <div class="col-md-3 col-xs-12">
                    <div class="imgBx">
                       <img src="<?php echo base_url('assets/foto/letycia.jpg')?>" alt="">
                    </div>
                    <div class="details">
                       <h3>Letycia Lobato <br> <span>Nurse and Founder </span></h3>
                       <ul>
                           <li><a title="FanPage" href="https://www.facebook.com/letycialobatofanpage/"><i class="fab fa-facebook-f"></i></a> </li>
                           <li><a title="Twitter" href="https://twitter.com/letycia_lobato"><i class="fab fa-twitter"></i></a> </li>
                           <li><a title="Linkedin" href="#"><i class="fab fa-linkedin"></i></a> </li>
                       </ul>
                    </div>
                </div>
                <div class="col-md-4 col-xs-12">
                   
                </div>
               
           </div>

       </div>