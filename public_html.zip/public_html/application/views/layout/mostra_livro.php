<?php
    defined('BASEPATH') OR exit('URL inválido');
   // <?php foreach($liv as $p_chegando):
    
?>


<div class="container mostra-livro m-top-30">
    <div class="row">
    <div class="col-sm-12 col-md-offset-1 ">

        <div class="card">
            <div class="card-header">
                Livro escolhido 
            </div>

            
            <?php foreach($liv as $p_chegando): ?>
            <ul class="list-unstyled m-top-10 ">
            <?php $id = $p_chegando['id']?>
                <div class="row">
                    <div class="col-sm-8">
                        <li class="media m-bot-10 p-3">
                            <img class="mr-3" src="<?php echo base_url('assets/livros/'.$p_chegando['foto']) ?>" alt="Generic placeholder image">
                            <div class="media-body media-preco">
                                <h2 class="mt-0 mb-1"><?php echo $p_chegando['titulo'] ?></h5>
                                <p class="mt-0 mb-1">por <em><strong> <?php echo $p_chegando['autor'] ?></strong></em></p>
                                <p class="mt-0 mb-1 disp">Disponivel</p>
                                <p class="mt-0 mb-1"><span class=""><?php echo $p_chegando['preco'] ?></span> </p>
                            </div>
                        </li>
                    </div>
                    <div class="col-sm-4 ">
                        <a href="<?php echo $p_chegando['link'] ?>" target=_blank class="p-2"> <button type="button" class="btn btn-danger m-bot-10 "><span>COMPRAR AGORA  </span><i class="fas fa-play"></i> </button></a> 
                    </div>
                </div>
           
                
            <div class="card-header">
                Descrição 
            </div>
            
            <div class="media-body p-2">
                <p class="mt-0 mb-1"><?php echo $p_chegando['descricao'] ?></p>
            </div>           
            </ul>
            <?php endforeach; ?>
        </div>


    </div><!-- col 12 offset-->
    </div><!-- row-->
</div><!-- Container-->

