<?php
    defined('BASEPATH') OR exit('URL inválido');
?>

    <div class="contenitore psi-cont m-top-40">
        <div class="row">
            <div class="col-sm-6">
                <h4 class="psicologia_title">Psicologia</h4>
            </div> 
            <div class="col-sm-6 nutri">
                <h4 class="nutricao_title">Nutrição</h4>
            </div> 
        </div>
        <div class="row m-top-40">
            <div class="col-sm-6" ><!-- Noticia Principale-->
                <?php foreach($psi as $p): ?>
                    <?php  $id = $p['id'] ?>
                    <?php  $url_slug = $p['url_slug'] ?>
                    <div class="row par-psi">
                        <div class="col-sm-12 tit-psi">
                            <a class="a-leia " href="<?php echo site_url("blog/artigo/$id/$url_slug") ?>">
                                <h4><?php echo $p['titulo'] ?></h4>
                            </a>
                        </div>
                    </div>    
                    <div class="row ">
                        <div class="col-sm-5 ">
                            <p><?php echo $p['descricao'] ?></p>
                            <hr>
                            <p><i class="far fa-clock"></i> <?php echo $p['data_post'] ?></p>
                        </div>
                        <div class="col-sm-7 ">
                            <a class="a-leia " href="<?php echo site_url("blog/artigo/$id/$url_slug") ?>">
                                <img src="<?php echo base_url('assets/foto/'.$p['foto'])?>" alt="">
                            </a>    
                        </div>
                    </div>
                <?php endforeach;  ?>
            </div>
            
            <div class="col-sm-6 nutri"> <!-- Noticia Lifestyle -->
                <div class="col-sm-12 nutri-resp m-top-40">
                    <h4 class="medicina_title">Nutrição</h4>
                </div> 
                <div class="card-columns">
                    <?php foreach($nut as $n): ?>
                    <?php  $id = $n['id'] ?>
                    <?php  $url_slug = $n['url_slug'] ?>
                    <div class="card">
                        <a class="a-leia " href="<?php echo site_url("blog/artigo/$id/$url_slug") ?>">
                            <img class="card-img-top" src="<?php echo base_url('assets/foto/'.$n['foto'])?>" alt="Card image cap">
                        </a>
                        <div class="card-body">
                        <a class="a-leia " href="<?php echo site_url("blog/artigo/$id/$url_slug") ?>">
                            <h5 class="card-title"><?php echo $n['titulo'] ?></h5>
                        </a>
                        <p class="card-text"><?php echo $n['descricao'] ?></p>
                        <p><i class="far fa-clock"></i> <?php echo $n['data_post'] ?></p>
                        </div>
                    </div>
                    <?php endforeach;  ?>
                </div>
                
            </div> <!-- Fine Div -->
        </div>
    </div>