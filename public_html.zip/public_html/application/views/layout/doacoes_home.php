<?php
    defined('BASEPATH') OR exit('URL inválido');

?>

    <div class="container mt-5 mb-5">
    <div class="row">
        <div class="col-sm-6 offset-3 col-8 offset-2">
            <div class="card p-4">
            <h4>ATENÇÃO</h4>
            <div class="alert alert-danger" role="alert">
                <i class="fas fa-exclamation-triangle"></i> Page Builder ! 
            </div>

            </div>
        </div>
    </div>
</div>
