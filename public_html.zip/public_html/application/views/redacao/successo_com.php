<?php
    defined('BASEPATH') OR exit('URL inválido');
   // <a href="<?php echo site_url('aplicativo/inserir_artigo.php') 
   // <a href="<?php echo site_url('geral') 
?>

<div class="contenitore mt-5">
    <div class="text-center alert alert-success">
        <p>Comentário inserido com successo! </p>
    </div>
</div>