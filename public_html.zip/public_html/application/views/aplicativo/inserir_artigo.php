<?php
    defined('BASEPATH') OR exit('URL inválido');

?>



<div class="contenitore m-top-30"><!-- Contenitore della notizia e della colonna vicina-->
    <div class="row">
        <div class="col-sm-10 offset-1 col-9 offset-1">
            <div class="card p-4">
            
                <table class="table table-hover table-dark">
                    <thead>
                        <tr>
                            <th scope="col" class="text-center">Legenda</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                        <th scope="row">Tags</th>
                            <td>Apertura <></td>
                            <td>Chiusura <></td>
                            <td>/ dentro <></td>
                        </tr>
                        <tr>
                        <th scope="row">Titolo</th>
                            <td><> Add h5</td>
                            <td><>Add /h5</td>
                            <td>/ dentro <></td>
                        </tr>
                        <tr>
                            <th scope="row">Paragrafo</th>
                            <td><>Add p</td>
                            <td><>Add /p</td>
                            <td>/ dentro <></td>
                        </tr>
                        <tr>
                            <th scope="row">Grassetto</th>
                            <td><>Add strong</td>
                            <td><>Add /strong</td>
                            <td>/ dentro <></td>
                        </tr>
                        <tr>
                            <th scope="row">Corsivo</th>
                            <td><>Add em</td>
                            <td><>Add /em</td>
                            <td>/ dentro <></td>
                        </tr>
                    </tbody>
                    
                </table>
                <div class="img-sintassi"><img src="../../assets/foto/sintassi.jpg"></div>
                <h4 class="text-center">Cria o teu artigo</h4>
                <hr>
                <?php  echo form_open_multipart('geral/criar_artigo');  ?>
                    <!--  inserir o titulo -->
                    <div class="form-group">
                        <input type="text" class="form-control" name="text-titulo"
                        placeholder="Inserir o titulo" required>
                    </div>
                    <hr>
                    <!--  escolher o setor -->
                    <h3>Escolhe o argumento do seu artigo</h3>
                    <div class="form-group">
                        <select 
                            name="nome_argumento" 
                            id="nome_argumento"
                            onchange="detalhes_argumento()" 
                            class="form-control">
                            <option value="0" disabled selected>Tipo de trabalho</option>
                            <?php foreach ($argomento as $ar) :?>
                                <option value="<?php echo $ar['id']?>"><?php echo $ar['descricao'] ?></option>
                            <?php endforeach;?>
                        </select>
                    </div>
                    <hr>
                    <!--  inserir a foto  -->
                    <h3>Inserir Foto principal</h3>
                    <div class="form-group">
                        <input type="file" name="ficheiro_foto" class="form-control" required>
                    </div>
                    <!--  inserir a descrição -->
                    <div class="form-group">
                        <input type="text" class="form-control" name="text-descricao"
                        placeholder="Inserir uma descrição do artigo" required>
                    </div>
                    <!--  inserir o artigo  -->
                    <div class="form-group">
                        <label for="">Inserir o teu artigo</label>
                        <textarea name="text-testo" class="form-control" rows="20"> </textarea>
                    </div>
                    <hr>
                    <div class="text-center">
                        <a href="<?php echo site_url('geral') ?>" class="btn btn-primary">Voltar</a>
                        <button class="btn btn-primary" type="submit">Criar artigo</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>


