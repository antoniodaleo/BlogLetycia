<?php
    defined('BASEPATH') OR exit('URL inválido');
?>

<div class="contenitore m-top-20"><!-- Contenitore della notizia e della colonna vicina-->
    <div class="row">
        <div class="col">
            <div id="carouselExampleSlidesOnly" class="carousel slide" data-ride="carousel">
                <div class="carousel-inner">
                    <div class="carousel-item active">
                    <a  href="<?php echo site_url('blog/livraria') ?>">
                        <img class="d-block w-100" src="<?php echo base_url('assets/foto/sae_banner.jpg') ?>" alt="First slide">
                    </a>
                    </div>
                    <div class="carousel-item">
                    <a href="<?php echo site_url('blog/livraria') ?>">
                        <img class="d-block w-100" src="<?php echo base_url('assets/foto/livros_banner.jpg') ?>" alt="Second slide">
                    </a>
                    </div>
                    
                </div>
            </div>
        </div>
    </div>
</div>