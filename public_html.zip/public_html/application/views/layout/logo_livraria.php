<?php
    defined('BASEPATH') OR exit('URL not valid'); 
?>
<div class="container m-top-10">
    <div class="row ">
        <div class="col-sm-3 amazon-logo">
            <div id="logo" class=" ">
                <div class="letycia">
                    <h1>BOOKSHOP <i class="fas fa-book-medical"></i></h1>
                    <p>Livros didáticos e manuais de enfermagem</p>
                </div> 
            </div>
        </div> 
        <div class="col-sm-7 amazon-logo">
            
        </div>
        <div class="col-sm-2 amazon-logo">
            <div class="card" style="width:100%;">
                <img class="card-img-top" src="<?php echo base_url('assets/foto/amazon-logo.png') ?>" alt="Card image cap">
                <span class="badge badge-warning m-top-10">Associados Amazon</span>
            </div>
        </div>
    </div>
        
  
</div>


