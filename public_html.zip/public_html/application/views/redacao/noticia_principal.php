<?php
    defined('BASEPATH') OR exit('URL inválido');
?>

  <div class="contenitore m-top-30 ">
        <div class="row ">
            <div class="col-sm-6 "> <!-- Articolo nuovo-->
                <?php foreach($news as $n): ?>
                <?php  $id = $n['id'] ?>
                <?php  $url_slug = $n['url_slug'] ?>
                    <div class="card text-white">
                        <a class="" href="<?php echo site_url("blog/artigo/$id/$url_slug")?>">
                            <img class="card-img" src="<?php echo base_url('assets/foto/'.$n['foto']) ?>" alt="Card image">
                        </a>
                        <div class="card-img-overlay">
                            <a class="" href="<?php echo site_url("blog/artigo/$id/$url_slug")?>">
                                <h4 class="card-title"><?php echo $n['titulo'] ?></h4>
                            </a>
                            <p class="card-text"><?php echo $n['descricao'] ?></p>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>

            <div class="col-sm-3 nt-p">
            <?php foreach($pol as $p): ?>
                <div class="card  text-white">
                    <?php  $id = $p['id'] ?>
                    <?php  $url_slug = $p['url_slug'] ?>
                    <a class="a-leia " href="<?php echo site_url("blog/artigo/$id/$url_slug") ?>">
                        <img class="card-img" src="<?php echo base_url('assets/foto/'.$p['foto']) ?>" alt="Card image">
                    </a>    
                    <div class="card-img-overlay">
                    <a class="a-leia " href="<?php echo site_url("blog/artigo/$id/$url_slug") ?>">
                        <h3 class="card-title"><?php echo $p['titulo'] ?></h3>
                    </a>   
                    </div>
                </div>
            <?php endforeach; ?>
            </div><!--Col m3 finito-->

            <div class="col-sm-3 nt-p2">
            <?php foreach($med as $m): ?>
                <div class="card  text-white">
                    <?php  $id = $m['id'] ?>
                    <?php  $url_slug = $m['url_slug'] ?>
                    <a class="a-leia " href="<?php echo site_url("blog/artigo/$id/$url_slug") ?>">
                        <img class="card-img" src="<?php echo base_url('assets/foto/'.$m['foto']) ?>" alt="Card image">
                    </a>    
                    <div class="card-img-overlay">
                    <a class="a-leia " href="<?php echo site_url("blog/artigo/$id/$url_slug") ?>">
                        <h3 class="card-title"><?php echo $m['titulo'] ?></h3>
                    </a>
                    </div>
                </div>
            <?php endforeach; ?>
            </div><!--Col m3 finito-->
        </div>
  </div>