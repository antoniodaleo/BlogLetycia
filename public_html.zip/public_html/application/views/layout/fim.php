<?php
    defined('BASEPATH') OR exit('URL inválido'); 
?>

<footer class="footer-main">
    <hr class="m-top-10">
    <div class="container m-bot-40">
        <div class="row m-top-10">
            <div class="col-md-4 m-top-10">
                <h4>LIVROS & CURSOS</h4>
                <!--BANNER-->
                <div class="card" >
                    <a href="<?php echo site_url('blog/livraria') ?>">
                        <img class="card-img-top" src="<?php echo base_url('assets/foto/livraria.jpg') ?>" alt="Card image cap">
                    </a>
                    <div class="card-body">
                        <p class="card-text">Na loja virtual, estudantes e profissionais da area da saude 
                        encontram livros didáticos e manuais de enfermagem para melhorar técnicas utilizadas 
                        nos hospitais. 
                        </p>
                        <a href="<?php echo site_url('blog/livraria') ?>">
                            <p class="card-text"><em>Visita à loja </em><i class="fas fa-arrow-right"></i></p>
                        </a>
                    </div>
                </div>   
            </div>
            <div class="col-md-4 m-top-10">
                <h4>SOCIAL NETWORK</h4>
                <p>FOLLOW US</p>
                <ul class="nav justify-content-left">
                    <li class="nav-item">
                        <a class="nav-link " href="https://www.facebook.com/letycialobatofanpage" target="_blank"><i class="fab fa-facebook-f"></i></a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="https://twitter.com/letycia_lobato" target="_blank"><i class="fab fa-twitter"></i></a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="#"><i class="fab fa-instagram"></i></a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link " href="#"><i class="fab fa-youtube"></i></a>
                    </li>
                </ul>
                <div class="card m-top-50" style="width: 100%;">
                    <div class="card-body">
                        <h5 class="card-title" ><i class="fas fa-envelope"></i> Newsletters</h5>
                    
                        <form action="<?php echo site_url('blog/add_email')?>" method="post">
                            <input type="text" class="form-control" name="text-email"
                            placeholder="Coloque aqui a sua email profissional" required>
                            <button class="btn btn-primary m-top-10" type="submit">Enviar</button>
                        </form>
                    </div>
                </div>
            </div>  
            <div class="col-md-4 m-top-10">
                <h4>QUEM SOMOS?</h4>
                <p>Eu e meu marido fundamos esse site no 2018. Nosso objetivo é  ser o melhor 
                    site de informação na area da saude. 
                    Quanto mais crescemos, mais vamos disseminar essa informação, ajudando 
                    as pessoas a contruir e viver em um mundo melhor.</p>

                <p>O que dá significado ao nosso trabalho é
                    uma equipe de colaboradores competente e treinada.</p>
                <a href="<?php echo site_url('blog/contatos') ?>">
                    <p><em>Leia mais</em>  <i class="fas fa-arrow-right"></i></p>
                </a>
            </div> 
        
            
        </div>
    </div>
    <!-- Copyright -->
    <div class="footer-copyright text-center">
            <p>©2018 COPYRIGHT LETYCIA LOBATO, TODOS OS DIREITOS RESERVADOS. PROIBIDA A REPRODUÇÃO SEM AUTORIZAÇÃO</p> 
    </div>
    
</footer>

</div><!--Fin container-->

<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script></body>
<script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>

<script type="text/javascript" src="<?php echo base_url('assets/js/javas.js') ?>"></script>

</body>
</html>