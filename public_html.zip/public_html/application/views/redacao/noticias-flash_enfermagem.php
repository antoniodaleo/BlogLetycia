<?php
    defined('BASEPATH') OR exit('URL inválido');
?>

        <div class="notizie-flash">
            <h5 id="tit-flash-alimentacao">Ultimas Enfermagem</h5>            
                <!--Link -->
               <ul class="">
                <?php foreach($nef as $a): ?>
                    <?php  $id = $a['id'] ?>
                    <?php  $url_slug = $a['url_slug'] ?>
                    <li>
                        <a href="<?php echo site_url("blog/artigo/$id/$url_slug") ?>">&rsaquo; <?php echo $a['titulo'] ?> </a>
                    </li>
                <?php endforeach; ?>
                </ul>
        </div>