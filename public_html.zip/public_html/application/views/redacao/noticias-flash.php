<?php
    defined('BASEPATH') OR exit('URL inválido');
?>

        <div class="notizie-flash" >
            <h5 id="tit-flash-news">Noticias flash</h5>            
                <ul class="">
                    <?php foreach($not as $n):   ?>
                    <?php  $id = $n['id'] ?>
                    <?php  $url_slug = $n['url_slug'] ?>
                    <li class="">
                        <a href="<?php echo site_url("blog/artigo/$id/$url_slug") ?>">&rsaquo; <?php echo $n['titulo'] ?> </a>
                    </li>
                    <?php endforeach;   ?>
                </ul>
        </div>

        