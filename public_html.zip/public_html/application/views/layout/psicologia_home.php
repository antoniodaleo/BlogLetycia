<?php
    defined('BASEPATH') OR exit('URL inválido');

?>

<div class="container m-top-20"><!-- Contenitore della notizia e della colonna vicina-->
    <h2 class="tit-principale">Psicologia </h2>    
    <div class="row">
        <div class="col-sm-8"><!--Colonna sin -->
                <?php foreach($art as $row) :?>
                    <div id="contenitore-articolo-wrapper">
                        <div class="articolo-wrapper "><!--articolo che deve contenere info piu piccole -->
                            <?php  $id = $row->id ?>
                            <?php  $url_slug = $row->url_slug ?>
                            <a class="a-leia " href="<?php echo site_url("blog/artigo/$id/$url_slug") ?>">
                                <img src="<?php echo base_url('assets/foto/'.$row->foto) ?>" alt="">  
                            </a>
                        </div>
                        <div class="descricao-wrapper "><!--Descricao h - p -->
                            <h4><?php echo $row->titulo ?></h4>
                            <p class=""> <?php echo $row->descricao ?> [<?php echo$row->data_post ?>]
                                <a class="a-leia " href="<?php echo site_url("blog/artigo/$id/$url_slug") ?>">
                                    <span><em> Leia mais &raquo</em></span> 
                                </a>
                            </p>
                        </div>
                    </div>
                <?php endforeach; ?>
                <div class="paginazione">
                    <nav aria-label="Page navigation example">
                        <ul class="pagination">
                            <?php  echo $pagination;  ?>
                        </ul>
                    </nav>  
                </div> 
        </div>
        <div class="col-sm-4 "><!--Colonna dest -->
            <div class="card" style="width: 100%;">
                <div class="card-body">
                    <h5 class="card-title" ><i class="fas fa-envelope"></i> Newsletters</h5>
                    <p>Que tal receber algumas noticias de conteúdo personalizadas pra você?</h5>
                    <form action="<?php echo site_url('blog/add_email')?>" method="post">
                        <input type="text" class="form-control" name="text-email"
                        placeholder="Coloque aqui a sua email profissional" required>
                        <button class="btn btn-primary m-top-10" type="submit">Enviar</button>
                    </form>
                </div>
            </div>  
            <!--Banner libreria-->
            <div class="row m-top-30">    
                <div id="carouselExampleSlidesOnly" class="carousel slide" data-ride="carousel">
                    <span class="badge badge-danger">VISITA O BOOKSHOP</span>
                    <div class="carousel-inner">
                        <div class="carousel-item active">
                        <a  href="<?php echo site_url('blog/livraria') ?>">
                            <img class="d-block w-100" src="<?php echo base_url('assets/foto/sae_banner.jpg') ?>" alt="First slide">
                        </a>
                        </div>
                        <div class="carousel-item">
                        <a href="<?php echo site_url('blog/livraria') ?>">
                            <img class="d-block w-100" src="<?php echo base_url('assets/foto/livros_banner.jpg') ?>" alt="Second slide">
                        </a>
                        </div>
                    </div>
                </div>
            </div>
            <?php //Pubblicita ----------------?>
            <div class="row m-top-30">
                <div class="card" style="width:100%;"> 
                    <script async src="//pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
                    <ins class="adsbygoogle"
                            style="display:block"
                            data-ad-format="fluid"
                            data-ad-layout-key="-h1+p-1k-cu+tf"
                            data-ad-client="ca-pub-2527299813629802"
                            data-ad-slot="6582160694"></ins>
                    <script>
                            (adsbygoogle = window.adsbygoogle || []).push({});
                    </script>
                </div>
            </div>
            <!--Video-->
            <div class="row m-top-40">
                <div class="card" style="width:100%;"> 
                    <?php foreach($vid as $v): ?>
                        <h4><span class="badge badge-success">TOP VIDEO</span> </h4>
                        <?php  echo $v['frame'];  ?> 
                        <h5 ><i class="fas fa-video"></i> <?php  echo $v['titulo']; ?>  </h5>
                    <?php endforeach;?>
                </div>             
            </div>
            <!-- Lista di libri-->
            <div class="row m-top-30">
                <div class="card" style="width:100%;">
                    <div class="card-header"> 
                        <h4 class=""><i class="fas fa-user-nurse"></i>Livros mais procurados</h4> 
                    </div>
                    <ul class="list-unstyled m-top-10">
                    <?php foreach($livpro as $e) : ?>
                        <li class="media m-bot-10">
                            <?php  $id = $e['id'] ?>
                            <?php  $url_slug = $e['url_slug'] ?>
                        <a class="" href="<?php echo site_url("blog/mostra_livro/$id/$url_slug")?>">    
                            <img class="mr-3" src="<?php echo base_url('assets/livros/'.$e['foto']) ?>" alt="Generic placeholder image">
                        </a>    
                        <div class="media-body">
                            <a class="" href="<?php echo site_url("blog/mostra_livro/$id/$url_slug")?>">    
                                <h5 class="mt-0 mb-1"><?php echo $e['titulo'] ?></h5>
                            </a>
                                <p class="mt-0 mb-1"><?php echo $e['autor'] ?></p>
                                <p class="mt-0 mb-1"><span class="badge badge-warning"><?php echo $e['preco'] ?></span> </p>
                        </div>
                        </li>
                    <?php endforeach; ?>
                    </ul>                        
                </div>   
            </div>
        </div>
    </div>
</div>