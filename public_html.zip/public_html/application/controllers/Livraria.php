<?php
    defined('BASEPATH') OR exit('URL inválido');

    class Livraria extends CI_Controller{

        //=============  Paginação livros de enfermagem
        public function enfermagem(){
            $this->load->library('pagination');
            $this->load->model('livros','p');
            $config['base_url'] = "http://localhost/public_html/livraria/enfermagem";
            $config['uri_segement'] = 3; 
            $config['per_page'] = 10; 
            
            //Pagination Style
            $config['full_tag_open']    = '<div class="pagging text-center"><nav><ul class="pagination">';
            $config['full_tag_close']   = '</ul></nav></div>';
            $config['num_tag_open']     = '<li class="page-item"><span class="page-link">';
            $config['num_tag_close']    = '</span></li>';
            $config['cur_tag_open']     = '<li class="page-item active"><span class="page-link">';
            $config['cur_tag_close']    = '<span class="sr-only">(current)</span></span></li>';
            $config['next_tag_open']    = '<li class="page-item"><span class="page-link">';
            $config['next_tag_close']  = '<span aria-hidden="true"></span></span></li>';
            // $config['next_tag_close']  = '<span aria-hidden="true">&raquo;</span></span></li>';
            $config['prev_tag_open']    = '<li class="page-item"><span class="page-link">';
            $config['prev_tag_close']  = '</span></li>';
            $config['first_tag_open']   = '<li class="page-item"><span class="page-link">';
            $config['first_tag_close'] = '</span></li>';
            $config['last_tag_open']    = '<li class="page-item"><span class="page-link">';
            $config['last_tag_close']  = '</span></li>';

            $page = $this->uri->segment(3,0); 
           
            $data['livenf'] = $this->p->get_livro_enfermagem($config['per_page'], $page); 
            $config['total_rows'] = $this->p->get_qtd_post_enf(); 
            $this->pagination->initialize($config); 
            $data['pagination'] = $this->pagination->create_links();
            
            $this->load->view('layout/inicio.php'); 
            $this->load->view('layout/nav_top.php'); 
            $this->load->view('layout/logo.php');
            $this->load->view('layout/nav_livraria.php'); 
            $this->load->view('livraria/livraria_enfermagem_home.php', $data);
            $this->load->view('layout/fim.php');
        }
        //=============  Paginação livros de medicina
        public function medicina(){
            $this->load->library('pagination');
            $this->load->model('livros','p');
            $config['base_url'] = "http://localhost/public_html/livraria/medicina";
            $config['uri_segement'] = 3; 
            $config['per_page'] = 10; 
            
            //Pagination Style
            $config['full_tag_open']    = '<div class="pagging text-center"><nav><ul class="pagination">';
            $config['full_tag_close']   = '</ul></nav></div>';
            $config['num_tag_open']     = '<li class="page-item"><span class="page-link">';
            $config['num_tag_close']    = '</span></li>';
            $config['cur_tag_open']     = '<li class="page-item active"><span class="page-link">';
            $config['cur_tag_close']    = '<span class="sr-only">(current)</span></span></li>';
            $config['next_tag_open']    = '<li class="page-item"><span class="page-link">';
            $config['next_tag_close']  = '<span aria-hidden="true"></span></span></li>';
            // $config['next_tag_close']  = '<span aria-hidden="true">&raquo;</span></span></li>';
            $config['prev_tag_open']    = '<li class="page-item"><span class="page-link">';
            $config['prev_tag_close']  = '</span></li>';
            $config['first_tag_open']   = '<li class="page-item"><span class="page-link">';
            $config['first_tag_close'] = '</span></li>';
            $config['last_tag_open']    = '<li class="page-item"><span class="page-link">';
            $config['last_tag_close']  = '</span></li>';

            $page = $this->uri->segment(3,0); 
             
            $data['livmed'] = $this->p->get_livro_medicina($config['per_page'], $page); 
            $config['total_rows'] = $this->p->get_qtd_post(); 
            $this->pagination->initialize($config); 
            $data['pagination'] = $this->pagination->create_links();
            
            $this->load->view('layout/inicio.php'); 
            $this->load->view('layout/nav_top.php'); 
            $this->load->view('layout/logo.php');
            $this->load->view('layout/nav_livraria.php'); 
            $this->load->view('livraria/livraria_medicina_home.php', $data);
            $this->load->view('layout/fim.php');
        }
        //=============  Paginação livros de nutricao
        public function nutricao(){
            $this->load->library('pagination');
            $this->load->model('livros','p');
            $config['base_url'] = "http://localhost/public_html/livraria/nutricao";
            $config['uri_segement'] = 3; 
            $config['per_page'] = 10; 
            
            //Pagination Style
            $config['full_tag_open']    = '<div class="pagging text-center"><nav><ul class="pagination">';
            $config['full_tag_close']   = '</ul></nav></div>';
            $config['num_tag_open']     = '<li class="page-item"><span class="page-link">';
            $config['num_tag_close']    = '</span></li>';
            $config['cur_tag_open']     = '<li class="page-item active"><span class="page-link">';
            $config['cur_tag_close']    = '<span class="sr-only">(current)</span></span></li>';
            $config['next_tag_open']    = '<li class="page-item"><span class="page-link">';
            $config['next_tag_close']  = '<span aria-hidden="true"></span></span></li>';
            // $config['next_tag_close']  = '<span aria-hidden="true">&raquo;</span></span></li>';
            $config['prev_tag_open']    = '<li class="page-item"><span class="page-link">';
            $config['prev_tag_close']  = '</span></li>';
            $config['first_tag_open']   = '<li class="page-item"><span class="page-link">';
            $config['first_tag_close'] = '</span></li>';
            $config['last_tag_open']    = '<li class="page-item"><span class="page-link">';
            $config['last_tag_close']  = '</span></li>';

            $page = $this->uri->segment(3,0); 
             
            $data['livnutri'] = $this->p->get_livro_nutricao($config['per_page'], $page); 
            $config['total_rows'] = $this->p->get_qtd_post_nutri(); 
            $this->pagination->initialize($config); 
            $data['pagination'] = $this->pagination->create_links();
            
            $this->load->view('layout/inicio.php'); 
            $this->load->view('layout/nav_top.php'); 
            $this->load->view('layout/logo.php');
            $this->load->view('layout/nav_livraria.php'); 
            $this->load->view('livraria/livraria_nutricao_home.php', $data);
            $this->load->view('layout/fim.php');
        }
        //=============  Paginação livros de psicologia
        public function psicologia(){
            $this->load->library('pagination');
            $this->load->model('livros','p');
            $config['base_url'] = "http://localhost/public_html/livraria/psicologia";
            $config['uri_segement'] = 3; 
            $config['per_page'] = 10; 
            
            //Pagination Style
            $config['full_tag_open']    = '<div class="pagging text-center"><nav><ul class="pagination">';
            $config['full_tag_close']   = '</ul></nav></div>';
            $config['num_tag_open']     = '<li class="page-item"><span class="page-link">';
            $config['num_tag_close']    = '</span></li>';
            $config['cur_tag_open']     = '<li class="page-item active"><span class="page-link">';
            $config['cur_tag_close']    = '<span class="sr-only">(current)</span></span></li>';
            $config['next_tag_open']    = '<li class="page-item"><span class="page-link">';
            $config['next_tag_close']  = '<span aria-hidden="true"></span></span></li>';
            // $config['next_tag_close']  = '<span aria-hidden="true">&raquo;</span></span></li>';
            $config['prev_tag_open']    = '<li class="page-item"><span class="page-link">';
            $config['prev_tag_close']  = '</span></li>';
            $config['first_tag_open']   = '<li class="page-item"><span class="page-link">';
            $config['first_tag_close'] = '</span></li>';
            $config['last_tag_open']    = '<li class="page-item"><span class="page-link">';
            $config['last_tag_close']  = '</span></li>';

            $page = $this->uri->segment(3,0); 
             
            $data['livpsico'] = $this->p->get_livro_psicologia($config['per_page'], $page); 
            $config['total_rows'] = $this->p->get_qtd_post_psico(); 
            $this->pagination->initialize($config); 
            $data['pagination'] = $this->pagination->create_links();
            
            $this->load->view('layout/inicio.php'); 
            $this->load->view('layout/nav_top.php'); 
            $this->load->view('layout/logo.php');
            $this->load->view('layout/nav_livraria.php'); 
            $this->load->view('livraria/livraria_psicologia_home.php', $data);
            $this->load->view('layout/fim.php');
        }
        //=============  Paginação livros de dieta
        public function dieta(){
            $this->load->library('pagination');
            $this->load->model('livros','p');
            $config['base_url'] = "http://localhost/public_html/livraria/dieta";
            $config['uri_segement'] = 3; 
            $config['per_page'] = 10; 
            
            //Pagination Style
            $config['full_tag_open']    = '<div class="pagging text-center"><nav><ul class="pagination">';
            $config['full_tag_close']   = '</ul></nav></div>';
            $config['num_tag_open']     = '<li class="page-item"><span class="page-link">';
            $config['num_tag_close']    = '</span></li>';
            $config['cur_tag_open']     = '<li class="page-item active"><span class="page-link">';
            $config['cur_tag_close']    = '<span class="sr-only">(current)</span></span></li>';
            $config['next_tag_open']    = '<li class="page-item"><span class="page-link">';
            $config['next_tag_close']  = '<span aria-hidden="true"></span></span></li>';
            // $config['next_tag_close']  = '<span aria-hidden="true">&raquo;</span></span></li>';
            $config['prev_tag_open']    = '<li class="page-item"><span class="page-link">';
            $config['prev_tag_close']  = '</span></li>';
            $config['first_tag_open']   = '<li class="page-item"><span class="page-link">';
            $config['first_tag_close'] = '</span></li>';
            $config['last_tag_open']    = '<li class="page-item"><span class="page-link">';
            $config['last_tag_close']  = '</span></li>';

            $page = $this->uri->segment(3,0); 
             
            $data['livdieta'] = $this->p->get_livro_dieta($config['per_page'], $page); 
            $config['total_rows'] = $this->p->get_qtd_post_dieta(); 
            $this->pagination->initialize($config); 
            $data['pagination'] = $this->pagination->create_links();
            
            $this->load->view('layout/inicio.php'); 
            $this->load->view('layout/nav_top.php'); 
            $this->load->view('layout/logo.php');
            $this->load->view('layout/nav_livraria.php'); 
            $this->load->view('livraria/livraria_dieta_home.php', $data);
            $this->load->view('layout/fim.php');
        }
        //=============  Paginação livros de autoajuda
        public function autoajuda(){
            $this->load->library('pagination');
            $this->load->model('livros','p');
            $config['base_url'] = "http://localhost/public_html/livraria/autoajuda";
            $config['uri_segement'] = 3; 
            $config['per_page'] = 10; 
            
            //Pagination Style
            $config['full_tag_open']    = '<div class="pagging text-center"><nav><ul class="pagination">';
            $config['full_tag_close']   = '</ul></nav></div>';
            $config['num_tag_open']     = '<li class="page-item"><span class="page-link">';
            $config['num_tag_close']    = '</span></li>';
            $config['cur_tag_open']     = '<li class="page-item active"><span class="page-link">';
            $config['cur_tag_close']    = '<span class="sr-only">(current)</span></span></li>';
            $config['next_tag_open']    = '<li class="page-item"><span class="page-link">';
            $config['next_tag_close']  = '<span aria-hidden="true"></span></span></li>';
            // $config['next_tag_close']  = '<span aria-hidden="true">&raquo;</span></span></li>';
            $config['prev_tag_open']    = '<li class="page-item"><span class="page-link">';
            $config['prev_tag_close']  = '</span></li>';
            $config['first_tag_open']   = '<li class="page-item"><span class="page-link">';
            $config['first_tag_close'] = '</span></li>';
            $config['last_tag_open']    = '<li class="page-item"><span class="page-link">';
            $config['last_tag_close']  = '</span></li>';

            $page = $this->uri->segment(3,0); 
             
            $data['livautoajuda'] = $this->p->get_livro_autoajuda($config['per_page'], $page); 
            $config['total_rows'] = $this->p->get_qtd_post_autoajuda(); 
            $this->pagination->initialize($config); 
            $data['pagination'] = $this->pagination->create_links();
            
            $this->load->view('layout/inicio.php'); 
            $this->load->view('layout/nav_top.php'); 
            $this->load->view('layout/logo.php');
            $this->load->view('layout/nav_livraria.php'); 
            $this->load->view('livraria/livraria_autoajuda_home.php', $data);
            $this->load->view('layout/fim.php');
        }
        //=============  Paginação livros de lifestyle
        public function lifestyle(){
            $this->load->library('pagination');
            $this->load->model('livros','p');
            $config['base_url'] = "http://localhost/public_html/livraria/lifestyle";
            $config['uri_segement'] = 3; 
            $config['per_page'] = 10; 
            
            //Pagination Style
            $config['full_tag_open']    = '<div class="pagging text-center"><nav><ul class="pagination">';
            $config['full_tag_close']   = '</ul></nav></div>';
            $config['num_tag_open']     = '<li class="page-item"><span class="page-link">';
            $config['num_tag_close']    = '</span></li>';
            $config['cur_tag_open']     = '<li class="page-item active"><span class="page-link">';
            $config['cur_tag_close']    = '<span class="sr-only">(current)</span></span></li>';
            $config['next_tag_open']    = '<li class="page-item"><span class="page-link">';
            $config['next_tag_close']  = '<span aria-hidden="true"></span></span></li>';
            // $config['next_tag_close']  = '<span aria-hidden="true">&raquo;</span></span></li>';
            $config['prev_tag_open']    = '<li class="page-item"><span class="page-link">';
            $config['prev_tag_close']  = '</span></li>';
            $config['first_tag_open']   = '<li class="page-item"><span class="page-link">';
            $config['first_tag_close'] = '</span></li>';
            $config['last_tag_open']    = '<li class="page-item"><span class="page-link">';
            $config['last_tag_close']  = '</span></li>';

            $page = $this->uri->segment(3,0); 
             
            $data['livlifestyle'] = $this->p->get_livro_lifestyle($config['per_page'], $page); 
            $config['total_rows'] = $this->p->get_qtd_post_lifestyle(); 
            $this->pagination->initialize($config); 
            $data['pagination'] = $this->pagination->create_links();
            
            $this->load->view('layout/inicio.php'); 
            $this->load->view('layout/nav_top.php'); 
            $this->load->view('layout/logo.php');
            $this->load->view('layout/nav_livraria.php'); 
            $this->load->view('livraria/livraria_lifestyle.php', $data);
            $this->load->view('layout/fim.php');
        }

    }
?>