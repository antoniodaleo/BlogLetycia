<?php
    defined('BASEPATH') OR exit('URL inválido');

    class Email extends CI_Model{
        
        public function inserir_email(){
            $dados = array(
                'email' => $this->input->post('text-email'),      
            );
            $this->db->insert('email', $dados); 
        }
       

    }
?>