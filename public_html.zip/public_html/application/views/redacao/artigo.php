<?php
    defined('BASEPATH') OR exit('URL inválido');
?>
 <!--La parte dell articolo in mostra =====================================================-->
<div class="container m-top-30">
    <div class="row">
        <div class="col-sm-8 testo-contenitore">
            <?php foreach($p as $p_chegando): ?>
                <?php  $id = $p_chegando['id']?>
                <div class="row">
                    <div class="col-sm-12">
                        <p id="p-data" class="">LetyciaLobato flash, <?php echo $p_chegando['data_post']?>  </p>     
                    </div>
                </div>
                <div class="row">
                    <div class="col-sm-12">
                        <h3 class="m-top-10"><?php echo $p_chegando['titulo']?>  </h3> 
                        <p id="p-descricao"><?php echo $p_chegando['descricao']?>  </p>
                    </div>
                </div>
                
                <hr> 
                <!--Compartilhar iconas-->
                <div class="row">
                    <div class="col-sm-12">
                        <ul id="icons">
                            <li class="">
                                <a target="_blank" href="https://www.facebook.com/sharer/sharer.php?u=https%3A%2F%2Fdevelopers.facebook.com%2Fdocs%2Fplugins%2F&amp;src=sdkpreparse" >
                                    <i class="fab fa-facebook-square"></i></a>
                                </a>
                            </li>
                            <li>
                                <a href="https://twitter.com/share?ref_src=twsrc%5Etfw" 
                                    target="_blank"><i class="fab fa-twitter-square"></i>
                                </a>
                                <script async src="https://platform.twitter.com/widgets.js" charset="utf-8"></script>
                            </li>
                        </ul>
                    </div>
                </div>
                <div class="row">
                    <div class="col-sm-12">
                        <img  class="card-img" src="<?php echo base_url('assets/foto/'.$p_chegando['foto']) ?>" alt="<?php echo $p_chegando['legenda']  ?>" title="<?php echo $p_chegando['legenda']  ?>">
                    </div>
                </div>
                <br>
                <div class="row">
                    <div class="col-md-12">
                        <?php echo $p_chegando['testo']?>
                        <?php //Pubblicita ----------------?>
                        <div class="row m-top-30">
                            <div class="card" style="width:100%;"> 
                                <script async src="//pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
                                <ins class="adsbygoogle"
                                        style="display:block"
                                        data-ad-format="fluid"
                                        data-ad-layout-key="-h1+p-1k-cu+tf"
                                        data-ad-client="ca-pub-2527299813629802"
                                        data-ad-slot="6582160694"></ins>
                                <script>
                                        (adsbygoogle = window.adsbygoogle || []).push({});
                                </script>
                            </div>
                        </div>'
                    </div>
                </div>

            <?php endforeach; ?>

            <!--Sezione commentari-->
            <div class="container m-top-50">
                <h4 class="tit-principale">Feedback</h4>
                <div class="row m-top-20">
                    <?php foreach($come as $c): ?> 
                        <div class="col-md-2">
                            <p><strong> <?php echo $c['nome']?> </strong></p>
                        </div>
                        <div class="col-md-10">
                            <p><?php echo $c['comento']?> </p>
                        </div>
                        <hr>
                    <?php endforeach; ?>
                </div>
            </div>
            <!--Inserisci commentari-->
            <div class="card m-top-30">
                <div class="card-body">
                    <h5 class="card-title">Comentários</h5>
                    <form action="<?php echo site_url('blog/add_comentario')?>" method="post">
                        <div class="form-group">
                            <input  name="text-id" type="hidden" value="<?php echo $id?>">
                        </div>
                        <div class="form-group">
                            <label for="exampleFormControlTextarea1"></label>
                            <textarea name="text-comentario" class="form-control" id="exampleFormControlTextarea1" rows="3"></textarea>
                        </div>
                        <div class="form-group">
                            <label for="exampleFormControlInput1">Nome</label>
                            <input name="text-nome" type="nome" class="form-control" id="exampleFormControlInput1" placeholder="nome" required>
                        </div>
                        <div class="form-group">
                            <label >Email</label>
                            <input type="text" class="form-control" name="text-email"
                                placeholder="Coloque aqui a sua email" required>
                        </div>
                        <button type="submit" class="btn btn-warning">Enviar</button>
                    </form>

                </div>
            </div>
        </div>
    <!--L altra meta della pagina =====================================================-->
    <div class="col-sm-4 testo-contenitore">
        <!--Artigos in resaltos-->
        <div class="row m-top-40" >
            <div class="col-sm-12  art-res">
                <div class="card " style="width:100%;">
                    <h4><span class="badge badge-danger">ARTIGOS MAIS LIDO </span></h4> 
                    
                    <ul class="list-unstyled m-top-10">
                        <?php foreach($news as $n): ?>
                            <li class="media m-bot-10">                              
                                <div class="media-body">  
                                    <?php  $id = $n['id'] ?>
                                    <?php  $url_slug = $n['url_slug'] ?>  
                                    <a class="" href="<?php echo site_url("blog/artigo/$id/$url_slug")?>">
                                        <h5 class="mt-0 mb-1"><?php echo $n['titulo'] ?></h5>    
                                    </a>                
                                </div>
                            </li>
                        <?php endforeach;?>
                    </ul>
                </div>
            </div>
        </div>
        <!--Banner libreria-->
        <div class="row m-top-30">    
            <div id="carouselExampleSlidesOnly" class="carousel slide" data-ride="carousel">
                <span class="badge badge-danger">VISITA O BOOKSHOP</span>
                <div class="carousel-inner">
                    <div class="carousel-item active">
                    <a  href="<?php echo site_url('blog/livraria') ?>">
                        <img class="d-block w-100" src="<?php echo base_url('assets/foto/sae_banner.jpg') ?>" alt="First slide">
                    </a>
                    </div>
                    <div class="carousel-item">
                    <a href="<?php echo site_url('blog/livraria') ?>">
                        <img class="d-block w-100" src="<?php echo base_url('assets/foto/livros_banner.jpg') ?>" alt="Second slide">
                    </a>
                    </div>
                </div>
            </div>
        </div>
       
        <?php //Pubblicita ----------------?>
        <div class="row m-top-30">
            <div class="card" style="width:100%;"> 
                <script async src="//pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
                <ins class="adsbygoogle"
                        style="display:block"
                        data-ad-format="fluid"
                        data-ad-layout-key="-h1+p-1k-cu+tf"
                        data-ad-client="ca-pub-2527299813629802"
                        data-ad-slot="6582160694"></ins>
                <script>
                        (adsbygoogle = window.adsbygoogle || []).push({});
                </script>
            </div>
        </div>

        <!--Video-->
        <div class="row m-top-40">
            <div class="card" style="width:100%;"> 
                <?php foreach($vid as $v): ?>
                    <h4><span class="badge badge-success">TOP VIDEO</span> </h4>
                    <?php  echo $v['frame'];  ?> 
                    <h5 ><i class="fas fa-video"></i> <?php  echo $v['titulo']; ?>  </h5>
                <?php endforeach;?>
            </div>             
        </div>
        <!-- Lista di libri-->
        <div class="row m-top-30">
            <div class="card" style="width:100%;">
                <div class="card-header"> 
                    <h4 class=""><i class="fas fa-user-nurse"></i>Livros mais procurados</h4> 
                </div>
                <ul class="list-unstyled m-top-10">
                <?php foreach($livpro as $e) : ?>
                    <li class="media m-bot-10">
                        <?php  $id = $e['id'] ?>
                        <?php  $url_slug = $e['url_slug'] ?>
                    <a class="" href="<?php echo site_url("blog/mostra_livro/$id/$url_slug")?>">    
                        <img class="mr-3" src="<?php echo base_url('assets/livros/'.$e['foto']) ?>" alt="Generic placeholder image">
                    </a>    
                    <div class="media-body">
                        <a class="" href="<?php echo site_url("blog/mostra_livro/$id/$url_slug")?>">    
                            <h5 class="mt-0 mb-1"><?php echo $e['titulo'] ?></h5>
                        </a>
                            <p class="mt-0 mb-1"><?php echo $e['autor'] ?></p>
                            <p class="mt-0 mb-1"><span class="badge badge-warning"><?php echo $e['preco'] ?></span> </p>
                    </div>
                    </li>
                <?php endforeach; ?>
                </ul>                        
            </div>   
        </div>

        <!-- Curtir pagina -->
        <div class="row m-top-30">
            <div class="card" style="width:100%;"> 
                <div class="fb-page" data-href="https://www.facebook.com/letycialobatofanpage/?modal=admin_todo_tour" data-tabs="timeline" data-width="500" data-height="530" data-small-header="true" data-adapt-container-width="true" data-hide-cover="false" data-show-facepile="true"><blockquote cite="https://www.facebook.com/letycialobatofanpage/?modal=admin_todo_tour" class="fb-xfbml-parse-ignore"><a href="https://www.facebook.com/letycialobatofanpage/?modal=admin_todo_tour">Letycialobato</a></blockquote></div>
            </div>
        </div>
        <?php //Pubblicita ----------------?>
        <div class="row m-top-30">
            <div class="card" style="width:100%;"> 
                <script async src="//pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
                <ins class="adsbygoogle"
                        style="display:block"
                        data-ad-format="fluid"
                        data-ad-layout-key="-h1+p-1k-cu+tf"
                        data-ad-client="ca-pub-2527299813629802"
                        data-ad-slot="6582160694"></ins>
                <script>
                        (adsbygoogle = window.adsbygoogle || []).push({});
                </script>
            </div>
        </div>
    </div>


    </div><!--Row fine-->
</div><!--Container fine-->

<hr class="break">