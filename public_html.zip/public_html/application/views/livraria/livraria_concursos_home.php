<?php
    defined('BASEPATH') OR exit('URL inválido');
?>
<div class="container m-top-50">
    <h4 class="titolo-shopping m-bot-30 ">Concursos</h4>
    <!--Prima sezione-->
    <div class="row m-bot-30">
        <div class="col-md-2 col">
            <iframe style="width:120px;height:240px;" marginwidth="0" marginheight="0" scrolling="no" frameborder="0" src="//ws-na.amazon-adsystem.com/widgets/q?ServiceVersion=20070822&OneJS=1&Operation=GetAdHtml&MarketPlace=BR&source=ac&ref=tf_til&ad_type=product_link&tracking_id=antonio1981-20&marketplace=amazon&region=BR&placement=8577710807&asins=8577710807&linkId=390f70c30c933687278338b8fc983ed3&show_border=true&link_opens_in_new_window=true&price_color=2b2727&title_color=0066c0&bg_color=ffffff">
            </iframe>
        </div>
        <div class="col-md-2 col">
            <iframe style="width:120px;height:240px;" marginwidth="0" marginheight="0" scrolling="no" frameborder="0" src="//ws-na.amazon-adsystem.com/widgets/q?ServiceVersion=20070822&OneJS=1&Operation=GetAdHtml&MarketPlace=BR&source=ac&ref=tf_til&ad_type=product_link&tracking_id=antonio1981-20&marketplace=amazon&region=BR&placement=B00UNIW5AW&asins=B00UNIW5AW&linkId=ca8857cb03aa122ffe67e3fd830a06f0&show_border=true&link_opens_in_new_window=true&price_color=2b2727&title_color=0066c0&bg_color=ffffff">
            </iframe>
        </div>
        <div class="col-md-2 col">
            <iframe style="width:120px;height:240px;" marginwidth="0" marginheight="0" scrolling="no" frameborder="0" src="//ws-na.amazon-adsystem.com/widgets/q?ServiceVersion=20070822&OneJS=1&Operation=GetAdHtml&MarketPlace=BR&source=ac&ref=tf_til&ad_type=product_link&tracking_id=antonio1981-20&marketplace=amazon&region=BR&placement=8567806542&asins=8567806542&linkId=979fdbc1847fc089726c47debd37442d&show_border=true&link_opens_in_new_window=true&price_color=2b2727&title_color=0066c0&bg_color=ffffff">
            </iframe>
        </div>
        <div class="col-md-2 col">
            <iframe style="width:120px;height:240px;" marginwidth="0" marginheight="0" scrolling="no" frameborder="0" src="//ws-na.amazon-adsystem.com/widgets/q?ServiceVersion=20070822&OneJS=1&Operation=GetAdHtml&MarketPlace=BR&source=ac&ref=tf_til&ad_type=product_link&tracking_id=antonio1981-20&marketplace=amazon&region=BR&placement=8581160646&asins=8581160646&linkId=d5b5f978492851d7b680e638077203d3&show_border=true&link_opens_in_new_window=true&price_color=2b2727&title_color=0066c0&bg_color=ffffff">
            </iframe>
        </div>
        <div class="col-md-2 col">
            <iframe style="width:120px;height:240px;" marginwidth="0" marginheight="0" scrolling="no" frameborder="0" src="//ws-na.amazon-adsystem.com/widgets/q?ServiceVersion=20070822&OneJS=1&Operation=GetAdHtml&MarketPlace=BR&source=ac&ref=tf_til&ad_type=product_link&tracking_id=antonio1981-20&marketplace=amazon&region=BR&placement=856780647X&asins=856780647X&linkId=24f1ec9801f5d0e0072386e8f382975b&show_border=true&link_opens_in_new_window=true&price_color=2b2727&title_color=0066c0&bg_color=ffffff">
            </iframe>
        </div>
        <div class="col-md-2 col">
            <iframe style="width:120px;height:240px;" marginwidth="0" marginheight="0" scrolling="no" frameborder="0" src="//ws-na.amazon-adsystem.com/widgets/q?ServiceVersion=20070822&OneJS=1&Operation=GetAdHtml&MarketPlace=BR&source=ac&ref=tf_til&ad_type=product_link&tracking_id=antonio1981-20&marketplace=amazon&region=BR&placement=8577710912&asins=8577710912&linkId=36864d98f053b1caae5cdfd7bd12e6e1&show_border=true&link_opens_in_new_window=true&price_color=2b2727&title_color=0066c0&bg_color=ffffff">
            </iframe>
        </div>
    </div>
    <!--Seconda sezione-->
    <div class="row m-bot-30">
        <div class="col-md-2 col">
            <iframe style="width:120px;height:240px;" marginwidth="0" marginheight="0" scrolling="no" frameborder="0" src="//ws-na.amazon-adsystem.com/widgets/q?ServiceVersion=20070822&OneJS=1&Operation=GetAdHtml&MarketPlace=BR&source=ac&ref=tf_til&ad_type=product_link&tracking_id=antonio1981-20&marketplace=amazon&region=BR&placement=8587600494&asins=8587600494&linkId=5d988f3d21a42bb38c36339b36c5fe92&show_border=true&link_opens_in_new_window=true&price_color=2b2727&title_color=0066c0&bg_color=ffffff">
            </iframe>
        </div>
        <div class="col-md-2 col">
            <iframe style="width:120px;height:240px;" marginwidth="0" marginheight="0" scrolling="no" frameborder="0" src="//ws-na.amazon-adsystem.com/widgets/q?ServiceVersion=20070822&OneJS=1&Operation=GetAdHtml&MarketPlace=BR&source=ac&ref=tf_til&ad_type=product_link&tracking_id=antonio1981-20&marketplace=amazon&region=BR&placement=B00CXTMNDS&asins=B00CXTMNDS&linkId=4e264117e2e8d4bc3b6b5c173bb46b79&show_border=true&link_opens_in_new_window=true&price_color=2b2727&title_color=0066c0&bg_color=ffffff">
            </iframe>
        </div>
        <div class="col-md-2 col">
            <iframe style="width:120px;height:240px;" marginwidth="0" marginheight="0" scrolling="no" frameborder="0" src="//ws-na.amazon-adsystem.com/widgets/q?ServiceVersion=20070822&OneJS=1&Operation=GetAdHtml&MarketPlace=BR&source=ac&ref=tf_til&ad_type=product_link&tracking_id=antonio1981-20&marketplace=amazon&region=BR&placement=B01MY0Y9BW&asins=B01MY0Y9BW&linkId=82338389cceaa913a8e0c32d32a68ada&show_border=true&link_opens_in_new_window=true&price_color=2b2727&title_color=0066c0&bg_color=ffffff">
            </iframe>
        </div>
        <div class="col-md-2 col">
            <iframe style="width:120px;height:240px;" marginwidth="0" marginheight="0" scrolling="no" frameborder="0" src="//ws-na.amazon-adsystem.com/widgets/q?ServiceVersion=20070822&OneJS=1&Operation=GetAdHtml&MarketPlace=BR&source=ac&ref=tf_til&ad_type=product_link&tracking_id=antonio1981-20&marketplace=amazon&region=BR&placement=8574981893&asins=8574981893&linkId=b6f2bb067318ffe3fe51829232eaa274&show_border=true&link_opens_in_new_window=true&price_color=2b2727&title_color=0066c0&bg_color=ffffff">
            </iframe>
        </div>
        <div class="col-md-2 col">
            <iframe style="width:120px;height:240px;" marginwidth="0" marginheight="0" scrolling="no" frameborder="0" src="//ws-na.amazon-adsystem.com/widgets/q?ServiceVersion=20070822&OneJS=1&Operation=GetAdHtml&MarketPlace=BR&source=ac&ref=tf_til&ad_type=product_link&tracking_id=antonio1981-20&marketplace=amazon&region=BR&placement=8577710114&asins=8577710114&linkId=8e8b4e633d2800f0b9508bb8d047b851&show_border=true&link_opens_in_new_window=true&price_color=2b2727&title_color=0066c0&bg_color=ffffff">
            </iframe>
        </div>
        <div class="col-md-2 col">
            <iframe style="width:120px;height:240px;" marginwidth="0" marginheight="0" scrolling="no" frameborder="0" src="//ws-na.amazon-adsystem.com/widgets/q?ServiceVersion=20070822&OneJS=1&Operation=GetAdHtml&MarketPlace=BR&source=ac&ref=tf_til&ad_type=product_link&tracking_id=antonio1981-20&marketplace=amazon&region=BR&placement=8564956977&asins=8564956977&linkId=33040ea624c6a0aa3ddeb7cdd6bcd2b3&show_border=true&link_opens_in_new_window=true&price_color=2b2727&title_color=0066c0&bg_color=ffffff">
            </iframe>
        </div>
    </div>
    <!--Terça sezione-->
    <div class="row m-bot-30">
        <div class="col-md-2 col">
            <iframe style="width:120px;height:240px;" marginwidth="0" marginheight="0" scrolling="no" frameborder="0" src="//ws-na.amazon-adsystem.com/widgets/q?ServiceVersion=20070822&OneJS=1&Operation=GetAdHtml&MarketPlace=BR&source=ac&ref=tf_til&ad_type=product_link&tracking_id=antonio1981-20&marketplace=amazon&region=BR&placement=B00IVC05OU&asins=B00IVC05OU&linkId=36247d94201055e06efe062c5f90ae61&show_border=true&link_opens_in_new_window=true&price_color=2b2727&title_color=0066c0&bg_color=ffffff">
            </iframe>
        </div>
        <div class="col-md-2 col">
            <iframe style="width:120px;height:240px;" marginwidth="0" marginheight="0" scrolling="no" frameborder="0" src="//ws-na.amazon-adsystem.com/widgets/q?ServiceVersion=20070822&OneJS=1&Operation=GetAdHtml&MarketPlace=BR&source=ac&ref=tf_til&ad_type=product_link&tracking_id=antonio1981-20&marketplace=amazon&region=BR&placement=8588656701&asins=8588656701&linkId=e6d4bede78e23b115e4def09f8837694&show_border=true&link_opens_in_new_window=true&price_color=2b2727&title_color=0066c0&bg_color=ffffff">
            </iframe>
        </div>
        <div class="col-md-2 col">
            <iframe style="width:120px;height:240px;" marginwidth="0" marginheight="0" scrolling="no" frameborder="0" src="//ws-na.amazon-adsystem.com/widgets/q?ServiceVersion=20070822&OneJS=1&Operation=GetAdHtml&MarketPlace=BR&source=ac&ref=tf_til&ad_type=product_link&tracking_id=antonio1981-20&marketplace=amazon&region=BR&placement=8588656728&asins=8588656728&linkId=7b21704c3dc34ef247abb299ad61a7a1&show_border=true&link_opens_in_new_window=true&price_color=2b2727&title_color=0066c0&bg_color=ffffff">
            </iframe>
        </div>
        <div class="col-md-2 col">
            <iframe style="width:120px;height:240px;" marginwidth="0" marginheight="0" scrolling="no" frameborder="0" src="//ws-na.amazon-adsystem.com/widgets/q?ServiceVersion=20070822&OneJS=1&Operation=GetAdHtml&MarketPlace=BR&source=ac&ref=tf_til&ad_type=product_link&tracking_id=antonio1981-20&marketplace=amazon&region=BR&placement=8567806216&asins=8567806216&linkId=dfcc4736addc7dcedc21497810a94292&show_border=true&link_opens_in_new_window=true&price_color=2b2727&title_color=0066c0&bg_color=ffffff">
            </iframe>
        </div>
        <div class="col-md-2 col">
            <iframe style="width:120px;height:240px;" marginwidth="0" marginheight="0" scrolling="no" frameborder="0" src="//ws-na.amazon-adsystem.com/widgets/q?ServiceVersion=20070822&OneJS=1&Operation=GetAdHtml&MarketPlace=BR&source=ac&ref=tf_til&ad_type=product_link&tracking_id=antonio1981-20&marketplace=amazon&region=BR&placement=8588656620&asins=8588656620&linkId=0eca8488714c5ed3cf20120765e753f5&show_border=true&link_opens_in_new_window=true&price_color=2b2727&title_color=0066c0&bg_color=ffffff">
            </iframe>
        </div>
        <div class="col-md-2 col">
            <iframe style="width:120px;height:240px;" marginwidth="0" marginheight="0" scrolling="no" frameborder="0" src="//ws-na.amazon-adsystem.com/widgets/q?ServiceVersion=20070822&OneJS=1&Operation=GetAdHtml&MarketPlace=BR&source=ac&ref=tf_til&ad_type=product_link&tracking_id=antonio1981-20&marketplace=amazon&region=BR&placement=8587600621&asins=8587600621&linkId=1fd6f5dcd913d8a00297cb2b285760c9&show_border=true&link_opens_in_new_window=true&price_color=2b2727&title_color=0066c0&bg_color=ffffff">
            </iframe>
        </div>
    </div>