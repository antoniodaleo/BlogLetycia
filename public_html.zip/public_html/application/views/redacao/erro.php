<?php
    defined('BASEPATH') OR exit('URL inválido');
?>

<div class="container mt-5 mb-5">
    <div class="text-center alert alert-danger">
        <?php echo $erros ?>
    </div>
    <div class="text-center">
        <a href="<?php echo site_url('blog') ?>" class="btn btn-primary">Cancelar</a>
        <a href="<?php echo site_url('redacao/inserir_articolo.php') ?>" class="btn btn-primary">Tenta de novo</a>
    </div>

</div>