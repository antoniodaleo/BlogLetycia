<?php
    defined('BASEPATH') OR exit('URL inválido');
?>
<div class="contenitore m-top-40">
    <div class="row">
        <h4 class="panorama_title">Panorama</h4>
    </div>
    <div class="row m-10">
        <div class="col-sm-9 ">
            <?php foreach($pan as $p): ?>
            <?php  $id = $p['id'] ?>
            <?php  $url_slug = $p['url_slug'] ?>

            <div class="card" style="width: 30%;">
                <a class="a-leia " href="<?php echo site_url("blog/artigo/$id/$url_slug") ?>">
                    <img class="card-img-top" src="<?php echo base_url('assets/foto/'.$p['foto']) ?>" alt="Card image cap">
                </a>    
                <div class="card-body">
                    <a class="a-leia " href="<?php echo site_url("blog/artigo/$id/$url_slug") ?>">
                        <h5 class="card-title"><?php echo $p['titulo'] ?></h5>
                    </a>
                    <p class="card-text"><?php echo $p['descricao'] ?></p>
                    <hr>
                    <p><i class="far fa-clock"></i> <?php echo $p['data_post'] ?></p>
                </div>
            </div>
            <?php endforeach;?>
        </div>
        <div class="col-sm-3 video">
            <?php foreach($vid2 as $v): ?>
                <?php  echo $v['frame'];  ?>
                <h5><i class="fas fa-video"></i>  <?php  echo $v['titulo'];  ?> </h5>
            <?php endforeach;?>
        </div>
    </div>
</div>