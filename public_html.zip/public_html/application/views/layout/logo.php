<?php
    defined('BASEPATH') OR exit('URL not valid'); 
?>

<div id="logo" class="m-bot-10">
    <div class="letycia">
        <h1>Letycia Lobato <i class="fas fa-heartbeat"></i></h1>
        <p>Blog de enfermagem e saude</p>
    </div> 
</div>

