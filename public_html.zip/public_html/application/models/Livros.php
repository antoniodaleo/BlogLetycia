<?php
    defined('BASEPATH') OR exit('URL inválido');

    class Livros extends CI_Model{
        //===================================================================== Home della libreria
        public function select_livro($id){
            $res = $this->db->select('*')
                ->from('livros')
                ->where('id',$id)
                ->get();

            return $res->result_array();  
        }
        // 3 libri di psicologia
        public function mostra_livro_psicologia(){
            $resultado =$this->db
            ->query('select * from livros  where id_arg = 9 order by id desc limit 1,4'); 
            return $resultado->result_array(); 
        }
        // 3 libri di medicina
        public function mostra_livro_medicina(){
            $resultado =$this->db
            ->query('select * from livros  where id_arg = 2 order by id desc limit 1,4'); 
            return $resultado->result_array(); 
        }
        // 3 libri di enfermagem
        public function mostra_livro_enfermagem_3(){
            $resultado =$this->db
            ->query('select * from livros  where id_arg = 1 order by id desc limit 4,3'); 
            return $resultado->result_array(); 
        }
        public function mostra_livro_enfermagem(){
            $resultado =$this->db
            ->query('select * from livros  where id_arg = 1 order by id desc limit 1,3'); 
            return $resultado->result_array(); 
        }
        // 2 libri di nutricao
        public function mostra_livro_nutricao(){
            $resultado =$this->db
            ->query('select * from livros  where id_arg = 3 order by id desc limit 1,2'); 
            return $resultado->result_array(); 
        }
        // 2 libri di dieta
        public function mostra_livro_dieta(){
            $resultado =$this->db
            ->query('select * from livros  where id_arg = 10 order by id desc limit 1,1'); 
            return $resultado->result_array(); 
        }
        // 2 libri di autojauda
        public function mostra_livro_autoajuda(){
            $resultado =$this->db
            ->query('select * from livros  where id_arg = 11 order by id desc limit 1,3'); 
            return $resultado->result_array(); 
        }
        // 2 libri di lifestyle
        public function mostra_livro_lifestyle_2(){
            $resultado =$this->db
            ->query('select * from livros  where id_arg = 8 order by id desc limit 2'); 
            return $resultado->result_array(); 
        }
        // 4 libri di tutte categorie
        public function mostra_libri_sulla_home(){
            $resultado = $this->db
            ->query('select*from livros order by id desc limit 4');
            return $resultado->result_array(); 
        }
        //===================================================================== Paginazione della libreria
        
        
        // Libri di enfermagem sulla enfermagem_home id_arg=1
        public function get_qtd_post_enf(){
            $sql = explode('LIMIT',$this->lastQuery);
            $query =  $this->db->query($sql[0]);
            $this->db->where('id_arg', 1); 
            $result = $query->result(); 
            return count($result); 
            print_r($sql); exit; 
        }
         public function get_livro_enfermagem($limit, $start){
            $this->db->order_by('id', 'desc'); 
            $this->db->limit($limit, $start); 
            $this->db->where('id_arg', 1); 
            $query = $this->db->get('livros'); 
            $this->lastQuery = $this->db->last_query(); 
 
            if($query->num_rows()>0){
                return $query->result(); 
            }else{
                return false; 
            }
        }


        // Libri di medicina sulla medicina_home id_arg=2
        public function get_qtd_post(){
            $sql = explode('LIMIT',$this->lastQuery);
            $query =  $this->db->query($sql[0]);
            $this->db->where('id_arg', 2); 
            $result = $query->result(); 
            return count($result); 
            print_r($sql); exit; 
        }
         public function get_livro_medicina($limit, $start){
            $this->db->order_by('id', 'desc'); 
            $this->db->limit($limit, $start); 
            $this->db->where('id_arg', 2); 
            $query = $this->db->get('livros'); 
            $this->lastQuery = $this->db->last_query(); 
 
            if($query->num_rows()>0){
                return $query->result(); 
            }else{
                return false; 
            }
        }
    
        // Libri di medicina sulla nutricao_home id_arg=2(13)
        public function get_qtd_post_nutri(){
            $sql = explode('LIMIT',$this->lastQuery);
            $query =  $this->db->query($sql[0]);
            $this->db->where('id_arg', 3); 
            $result = $query->result(); 
            return count($result); 
            print_r($sql); exit; 
        }
         public function get_livro_nutricao($limit, $start){
            $this->db->order_by('id', 'desc'); 
            $this->db->limit($limit, $start); 
            $this->db->where('id_arg', 3); 
            $query = $this->db->get('livros'); 
            $this->lastQuery = $this->db->last_query(); 
 
            if($query->num_rows()>0){
                return $query->result(); 
            }else{
                return false; 
            }
        }
        // Libri di psicologia sulla psicologia_home id_arg=2(18)
        public function get_qtd_post_psico(){
            $sql = explode('LIMIT',$this->lastQuery);
            $query =  $this->db->query($sql[0]);
            $this->db->where('id_arg', 9); 
            $result = $query->result(); 
            return count($result); 
            print_r($sql); exit; 
        }
         public function get_livro_psicologia($limit, $start){
            $this->db->order_by('id', 'desc'); 
            $this->db->limit($limit, $start); 
            $this->db->where('id_arg', 9); 
            $query = $this->db->get('livros'); 
            $this->lastQuery = $this->db->last_query(); 
 
            if($query->num_rows()>0){
                return $query->result(); 
            }else{
                return false; 
            }
        }
        // Libri di psicologia sulla dieta id_arg=2(18)
        public function get_qtd_post_dieta(){
            $sql = explode('LIMIT',$this->lastQuery);
            $query =  $this->db->query($sql[0]);
            $this->db->where('id_arg', 10); 
            $result = $query->result(); 
            return count($result); 
            print_r($sql); exit; 
        }
         public function get_livro_dieta($limit, $start){
            $this->db->order_by('id', 'desc'); 
            $this->db->limit($limit, $start); 
            $this->db->where('id_arg', 10); 
            $query = $this->db->get('livros'); 
            $this->lastQuery = $this->db->last_query(); 
 
            if($query->num_rows()>0){
                return $query->result(); 
            }else{
                return false; 
            }
        }
        // Libri di autoajuda
        public function get_qtd_post_autoajuda(){
            $sql = explode('LIMIT',$this->lastQuery);
            $query =  $this->db->query($sql[0]);
            $this->db->where('id_arg', 11); 
            $result = $query->result(); 
            return count($result); 
            print_r($sql); exit; 
        }
         public function get_livro_autoajuda($limit, $start){
            $this->db->order_by('id', 'desc'); 
            $this->db->limit($limit, $start); 
            $this->db->where('id_arg', 11); 
            $query = $this->db->get('livros'); 
            $this->lastQuery = $this->db->last_query(); 
 
            if($query->num_rows()>0){
                return $query->result(); 
            }else{
                return false; 
            }
        }

        // Libri di life-style
        public function get_qtd_post_lifestyle(){
            $sql = explode('LIMIT',$this->lastQuery);
            $query =  $this->db->query($sql[0]);
            $this->db->where('id_arg', 8); 
            $result = $query->result(); 
            return count($result); 
            print_r($sql); exit; 
        }
        public function get_livro_lifestyle($limit, $start){
            $this->db->order_by('id', 'desc'); 
            $this->db->limit($limit, $start); 
            $this->db->where('id_arg', 8); 
            $query = $this->db->get('livros'); 
            $this->lastQuery = $this->db->last_query(); 
 
            if($query->num_rows()>0){
                return $query->result(); 
            }else{
                return false; 
            }
        }


    }
?>