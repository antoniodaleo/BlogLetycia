<?php
    defined('BASEPATH') OR exit('URL inválido');
?>

<div id="cont-life" class="contenitore m-top-40" >
    <div class="row  m-top-20 ">
        <div class="col-sm-12">
            <h4 class="medicina_title">Life Style</h4>
            <h2>Ajudando a garantir uma vida melhor e mais longa</h2>
        </div>
    </div>
    <div class="row m-top-20 card-life">
        <div class="col-sm-12 life">
        <div class="card-deck">
            <?php  foreach($lif as $l) :?>
            <?php  $id = $l['id'] ?>
            <?php  $url_slug = $l['url_slug'] ?>
            <div class="card">
                <a class="a-leia " href="<?php echo site_url("blog/artigo/$id/$url_slug") ?>">
                    <img class="card-img-top" src="<?php echo base_url('assets/foto/'.$l['foto']) ?>" alt="Card image cap">
                </a>
                <div class="card-body">
                <a class="a-leia " href="<?php echo site_url("blog/artigo/$id/$url_slug") ?>">
                    <h5 class="card-title"><?php echo $l['titulo'] ?></h5>
                </a>
                <p class="card-text"><?php echo $l['descricao'] ?></p>
                </div>
            </div>
            <?php endforeach;  ?>
        </div>
        </div>
    </div>
</div>