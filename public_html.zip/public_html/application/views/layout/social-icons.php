<?php
    defined('BASEPATH') OR exit('URL not valid'); 
?>

<div class="contenitore-social x">
    <ul id="icons">
        <li class="x"><a href="" class=""><i class="fab fa-facebook-square" aria-hidden="true"></i></a></li>
        <li><a href=""><i class="fab fa-twitter-square" aria-hidden="true"></i></a></li>
        <li><a href=""><i class="fas fa-envelope" aria-hidden="true"></i></a></li>
    </ul>

</div>