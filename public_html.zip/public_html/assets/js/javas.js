
//document.getElementById('lettera').style.color="blue"; 
//$('#lettera').css('color', 'black'); 
//$('ul li:first').css('color', 'green'); 
//window.onload= iniciar; 
//$('#p1').click(function(){$('#p2').toggle();});
//$('#p1').hover(function(){$('#p2').toggle();});

$(document).ready(function(){

    console.log('funciona');
    var parag = $('#resultado');

    $('#bot').click(function(){
        parag.addClass('display-4');
    });
    
    $('#botM').click(function(){
        parag.removeClass('display-4'); 
    })

})


