<?php
    defined('BASEPATH') OR exit('URL inválido');

    class Post extends CI_Model{
        //=================================================================== Index

        private $lastQuery= ''; 
        
        // Articoli di enfermagem sulla enfermagem_home 
        public function get_qtd_post(){
           $sql = explode('LIMIT',$this->lastQuery);
           $query =  $this->db->query($sql[0]);
           $this->db->where('id_argumento', 1); 
           $result = $query->result(); 
           return count($result); 
           print_r($sql); exit; 
        }
        public function get_post_enfermagem($limit, $start){
           $this->db->order_by('id', 'desc'); 
           $this->db->limit($limit, $start); 
           $this->db->where('id_argumento', 1); 
           $query = $this->db->get('post'); 
           $this->lastQuery = $this->db->last_query(); 

           if($query->num_rows()>0){
               return $query->result(); 
           }else{
               return false; 
           }
        }
        // Articoli di enfermagem sulla medicina_home 
        public function get_qtd_post_med(){
            $sql = explode('LIMIT',$this->lastQuery);
            $query =  $this->db->query($sql[0]);
            $this->db->where('id_argumento', 2); 
            $result = $query->result(); 
            return count($result); 
            print_r($sql); exit; 
         }
 
        public function get_post_medicina($limit, $start){
            $this->db->order_by('id', 'desc'); 
            $this->db->limit($limit, $start); 
            $this->db->where('id_argumento', 2); 
            $query = $this->db->get('post'); 
            $this->lastQuery = $this->db->last_query(); 
 
            if($query->num_rows()>0){
                return $query->result(); 
            }else{
                return false; 
            }
        }
        // Articoli di alimentacao sulla alimentaçao_home 
        public function get_qtd_post_ali(){
            $sql = explode('LIMIT',$this->lastQuery);
            $query =  $this->db->query($sql[0]);
            $this->db->where('id_argumento', 3); 
            $result = $query->result(); 
            return count($result); 
            print_r($sql); exit; 
         }
 
        public function get_post_alimentacao($limit, $start){
            $this->db->order_by('id', 'desc'); 
            $this->db->limit($limit, $start); 
            $this->db->where('id_argumento', 3); 
            $query = $this->db->get('post'); 
            $this->lastQuery = $this->db->last_query(); 
 
            if($query->num_rows()>0){
                return $query->result(); 
            }else{
                return false; 
            }
        }

        // Articoli di alimentacao sulla lifestyle_home 
        public function get_qtd_post_lif(){
            $sql = explode('LIMIT',$this->lastQuery);
            $query =  $this->db->query($sql[0]);
            $this->db->where('id_argumento', 8); 
            $result = $query->result(); 
            return count($result); 
            print_r($sql); exit; 
        }
        public function get_post_lifestyle($limit, $start){
            $this->db->order_by('id', 'desc'); 
            $this->db->limit($limit, $start); 
            $this->db->where('id_argumento', 8); 
            $query = $this->db->get('post'); 
            $this->lastQuery = $this->db->last_query(); 

            if($query->num_rows()>0){
                return $query->result(); 
            }else{
                return false; 
            }
        }
        // Articoli di alimentacao sulla news_home 
        public function get_qtd_post_news(){
            $sql = explode('LIMIT',$this->lastQuery);
            $query =  $this->db->query($sql[0]);
            $this->db->where('id_argumento', 5); 
            $result = $query->result(); 
            return count($result); 
            print_r($sql); exit; 
        }
        public function get_post_news($limit, $start){
            $this->db->order_by('id', 'desc'); 
            $this->db->limit($limit, $start); 
            $this->db->where('id_argumento', 5); 
            $query = $this->db->get('post'); 
            $this->lastQuery = $this->db->last_query(); 

            if($query->num_rows()>0){
                return $query->result(); 
            }else{
                return false; 
            }
        }
        // Articoli di alimentacao sulla panorama
        public function get_qtd_post_pan(){
            $sql = explode('LIMIT',$this->lastQuery);
            $query =  $this->db->query($sql[0]);
            $this->db->where('id_argumento', 4); 
            $result = $query->result(); 
            return count($result); 
            print_r($sql); exit; 
        }
        public function get_post_panorama($limit, $start){
            $this->db->order_by('id', 'desc'); 
            $this->db->limit($limit, $start); 
            $this->db->where('id_argumento', 4); 
            $query = $this->db->get('post'); 
            $this->lastQuery = $this->db->last_query(); 

            if($query->num_rows()>0){
                return $query->result(); 
            }else{
                return false; 
            }
        }
        // Articoli di alimentacao sulla psicologia
        public function get_qtd_post_psi(){
            $sql = explode('LIMIT',$this->lastQuery);
            $query =  $this->db->query($sql[0]);
            $this->db->where('id_argumento', 9); 
            $result = $query->result(); 
            return count($result); 
            print_r($sql); exit; 
        }
        public function get_post_psicologia($limit, $start){
            $this->db->order_by('id', 'desc'); 
            $this->db->limit($limit, $start); 
            $this->db->where('id_argumento', 9); 
            $query = $this->db->get('post'); 
            $this->lastQuery = $this->db->last_query(); 

            if($query->num_rows()>0){
                return $query->result(); 
            }else{
                return false; 
            }
        }

        // HomePage ====================================================== HomePage
        // Articoli di enfermagem sulla home 
        public function unoEnfermagem(){
            $resultado =$this->db
            ->query('select * from post  where id_argumento = 1 order by id desc limit 1,1'); 
            return $resultado->result_array(); 
        }
        public function tudoEnfermagem(){
            $resultado =$this->db
                ->query('select * from post  where id_argumento = 1 order by id desc limit 2,2'); 
            return $resultado->result_array(); 
        }
        // Articoli di politica sulla home 
        public function tudoPolitica(){
            $resultado =$this->db
            ->query('select * from post  where id_argumento = 5 order by id desc limit 1,2'); 
            return $resultado->result_array(); 
        }
        // Articoli di medicina sulla home 
        public function unoMedicina(){
            $resultado =$this->db
            ->query('select * from post  where id_argumento = 2 order by id desc limit 1,1'); 
            return $resultado->result_array(); 
        }
        public function tudoMedicina(){
            $resultado =$this->db
            ->query('select * from post  where id_argumento = 2 order by id desc limit 2,2'); 
            return $resultado->result_array(); 
        }
         // Articoli di psicologia sulla home 
         public function tudoPsicologia(){
            $resultado =$this->db
            ->query('select * from post  where id_argumento = 9 order by id desc limit 1,4'); 
            return $resultado->result_array(); 
        }
        // Articoli di panorama sulla home 
        public function tudoPanorama(){
            $resultado =$this->db
            ->query('select * from post  where id_argumento = 4 order by id desc limit 1,2'); 
            return $resultado->result_array(); 
        }

        //Elenco not enfermagem flash
        public function notizieflash_enfermagem(){
            $resultado =$this->db
                ->query('select * from post  where id_argumento = 1 order by id desc limit 1,6'); 
            return $resultado->result_array(); 
        }
        // Elenco articoli
        public function notizieflash(){
            $resultado =$this->db
                ->query('select * from post  where id_argumento = 5 order by id desc limit 1,6'); 
            return $resultado->result_array(); 
        }
        public function tudoAlimentacao(){
            $resultado =$this->db
                ->query('select * from post  where id_argumento = 3 order by id desc limit 1,3'); 
            return $resultado->result_array(); 
        }
        public function tudoAlimentacao_notizia(){
            $resultado =$this->db
                ->query('select * from post  where id_argumento = 3 order by id desc limit 1'); 
            return $resultado->result_array(); 
        }
        public function unoLifestyle_notizia(){
            $resultado =$this->db
                ->query('select * from post  where id_argumento = 8 order by id desc limit 1,1'); 
            return $resultado->result_array(); 
        }
        public function tudoLifestyle_notizia(){
            $resultado =$this->db
                ->query('select * from post  where id_argumento = 8 order by id desc limit 2,3'); 
            return $resultado->result_array(); 
        }

        // Prendiamo i video cadastrati
        public function video(){
            $resultado =$this->db
                ->query('select * from video order by id desc limit 1'); 
            return $resultado->result_array(); 
        }
        public function video_2(){
            $resultado =$this->db
                ->query('select * from video order by id desc limit 1,1'); 
            return $resultado->result_array(); 
        }



        // Voglio creare una piattaforma di inserzione dell articolo , in cui l usuario puo
        // tranquillamente editare e publicare dall applicazione.
        public function inserir_artigo($nome_foto){
            $dados = array(
                'id_argumento' =>$this->input->post('nome_argumento'),
                'titulo' => $this->input->post('text-titulo'),
                'descricao' => $this->input->post('text-descricao'),
                'data_post' => date('Y-m-d H:i:s'),
                'foto' =>$nome_foto,
                'testo' => $this->input->post('text-testo')        
            );
            $this->db->insert('post',$dados); 
        } 
        public function select_artigo($id){
            $res = $this->db->select('*')
                ->from('post')
                ->where('id',$id)
                ->get();

            return $res->result_array();  
        }
        //Seleziona articolo per titolo
        public function select_artigo_titulo($tit){
            $res = $this->db->select('*')
            ->from('post')
            ->where('titulo',$tit)
            ->get();

        return $res->result_array();  

        }
        public function select_ultimo_id($nome_foto){
            $resultado = $this->db->from('post')
                ->order_by('id','desc') 
                ->limit('1')
                ->get();
            
            $dados_id = $resultado->row(); 

            $dados = array(
                'id_post' =>  $dados_id->id,
                'img' => $nome_foto  
            );

            $this->db->insert('foto',$dados); 
        }
        // Mi selezioni l ultimo articolo che ho inserito e me===============================
        // lo mostri nella notizia principale
        public function ultimo_artigo(){
            $res = $this->db->query('select * from post order by id desc limit 1'); 
                return $res->result_array(); 
        }
    }  
?>
