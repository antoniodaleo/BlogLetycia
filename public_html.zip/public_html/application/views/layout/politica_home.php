<?php
    defined('BASEPATH') OR exit('URL inválido');

?>


<div class="contenitore m-top-20"><!-- Contenitore della notizia e della colonna vicina-->
    <h2 class="tit-principale">Politica</h2>
        <div class="colon-7 m-top-10"><!--Colonna sin -->
            <div class="cerca" id="cerca"><!--search -->
                <div class="form-group"><!--form -->
                    <form action="<?php echo site_url('geral/pesquisa')?>" method="post">
                        <p> <input type="text" class="form-control" name="text-cerca"
                            placeholder="Pesquisar">
                        </p>
                        <button class="btn btn-primary"><i class="fas fa-search"></i></button>      
                    </form>
                </div>
            </div>
            <?php foreach($query->result() as $row) :?>
            <div id="contenitore-articolo-wrapper">
                <div class="articolo-wrapper "><!--articolo che deve contenere info piu piccole -->
                    <?php  $id = $row->id ?>
                    <a class="a-leia " href="<?php echo site_url("geral/mostra_articolo?pId=$id") ?>">
                        <img src="<?php echo base_url('assets/foto/'.$row->foto) ?>" alt="">  
                    </a>
                </div>
                <div class="descricao-wrapper "><!--Descricao h - p -->
                    <h4><?php echo $row->titulo ?></h4>
                    <p class=""> <?php echo $row->descricao ?> [<?php echo$row->data_post ?>]
                        <a class="a-leia " href="<?php echo site_url("geral/mostra_articolo?pId=$id") ?>">
                            <span><em> Leia mais &raquo</em></span> 
                        </a>
                    </p>
                </div>
            </div>
            <?php endforeach; ?>

            <div class="paginazione">
                    <?php echo $this->pagination->create_links();?>
            </div>
           
        </div>
   
    
    <div class="colon-3 "><!--Colonna dest -->
        <div class="card" style="width: 100%;">
            <div class="card-body">
                <h5 class="card-title"><i class="fas fa-at"> </i> Newsletter</h5>
                <p class="card-text">Fica sempre atualizado, cadastra a sua email</p>

                <form action="<?php echo site_url('geral/add_email')?>" method="post">
                    <input type="email" class="form-control" name="text-email"
                    placeholder="exemplo@email.com" required>
                    <button class="btn btn-primary m-top-10" type="submit">Enviar</button>
                </form>
            </div>
        </div>  
    </div>
</div>




