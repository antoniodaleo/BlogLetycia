<?php
    defined('BASEPATH') OR exit('URL inválido');
?>


<div class="container">
<!--Banner publicita Amazon-->
    <div class="row">
        <div id="carouselExampleSlidesOnly" class="carousel slide" data-ride="carousel">
            <div class="carousel-inner">
                <div class="carousel-item active">
                    <img class="d-block w-100" src="<?php echo base_url('assets/foto/banner_sito.jpg') ?>" alt="Third slide">
                </div>
                <div class="carousel-item">
                    <img class="d-block w-100" src="<?php echo base_url('assets/foto/banner_livros.jpg') ?>" alt="Third slide">
                </div>
                <div class="carousel-item">
                    <img class="d-block w-100" src="<?php echo base_url('assets/foto/banner_publicidade_1.jpg') ?>" alt="Third slide">
                </div>
            </div>
        </div>
    </div>
</div>

<!-- SEZIONE DI PUBLICITA BANNER FISSO -->
<div class="container iniziale m-top-20">
    <div class="row m-top-30">
        <?php //Notizia primaria -------------------------------------------------------------- ?>
        <div class="col-sm-3 notizia-primaria m-bot-20">        
            <?php //Libri de psicologia e auto-ajuda 4 --------------- ?>
            <div class="row">   
                <div class="col-sm-12"> 
                    <div class="row">
                        <div class="card" style="width:100%;">
                            <div class="card-header">
                            <h4><i class="fas fa-brain"></i>  Psicologia </h4> 
                            </div>
                            <ul class="list-unstyled m-top-10">
                            <?php foreach($psi as $p): ?>
                                <li class="media m-bot-10">
                                    <?php  $id = $p['id'] ?>
                                    <?php  $url_slug = $p['url_slug'] ?>
                                    <a class="" href="<?php echo site_url("blog/mostra_livro/$id/$url_slug")?>">
                                        <img class="mr-3" src="<?php echo base_url('assets/livros/'.$p['foto']) ?>" alt="Generic placeholder image">
                                    </a>
                                    <div class="media-body">
                                    <a class="" href="<?php echo site_url("blog/mostra_livro/$id/$url_slug")?>">
                                        <h5 class="mt-0 mb-1"><?php echo $p['titulo'] ?></h5>
                                    </a>
                                        <p class="mt-0 mb-1"><?php echo $p['autor'] ?></p>
                                        <p class="mt-0 mb-1"><span class="badge badge-warning"><?php echo $p['preco'] ?></span> </p>
                                    </div>
                                </li>
                            <?php endforeach; ?>
                            </ul>
                        </div><?php //End card --------------- ?>   
                    </div>
                </div> <?php //End col12 --------------- ?>
           </div><?php //End row --------------- ?>
           
           <?php //Libri de Medicina 4 --------------- ?>
           <div class="row">   
                <div class="col-sm-12"> 
                    <div class="row">
                        <div class="card" style="width:100%;">
                            <div class="card-header">
                            <h4><i class="fas fa-star-of-life"></i> Top de Medicina</h4> 
                            </div>
                            <ul class="list-unstyled m-top-10">
                            <?php foreach($med as $p): ?>
                                <li class="media m-bot-10">
                                <?php  $id = $p['id'] ?>
                                <?php  $url_slug = $p['url_slug'] ?>
                                <a class="" href="<?php echo site_url("blog/mostra_livro/$id/$url_slug")?>">
                                    <img class="mr-3" src="<?php echo base_url('assets/livros/'.$p['foto']) ?>" alt="Generic placeholder image">
                                </a>    
                                    <div class="media-body">
                                    <a class="" href="<?php echo site_url("blog/mostra_livro/$id/$url_slug")?>">
                                        <h5 class="mt-0 mb-1"><?php echo $p['titulo'] ?></h5>
                                    </a>
                                        <p class="mt-0 mb-1"><?php echo $p['autor'] ?></p>
                                        <p class="mt-0 mb-1"><span class="badge badge-warning"><?php echo $p['preco'] ?></span> </p>
                                    </div>
                                </li>
                            <?php endforeach; ?>
                            </ul>
                        </div><?php //End card --------------- ?>   
                    </div>
                </div> <?php //End col12 --------------- ?>
           </div><?php //End row --------------- ?>
        </div>


        <?php //Notizia principale ------------------------------------------------------------?>
        <div class="col-sm-5 notizia-principale m-bot-20">
            <div class="row"><?php //3 Livros de enfermagem ----------------?>
                <div class="card" style="width:100%;">
                    <div class="card-header"> 
                       <h4><i class="fas fa-user-nurse"></i>  Livros de enfermagem</h4> 
                    </div>
                    <ul class="list-unstyled m-top-10">
                    <?php foreach($enf as $e) : ?>
                        <?php  $id = $e['id'] ?>
                        <?php  $url_slug = $e['url_slug'] ?>
                        <li class="media m-bot-10">
                            <?php $e['id'] ?>
                            <a class="" href="<?php echo site_url("blog/mostra_livro/$id/$url_slug")?>">
                                <img class="mr-3" src="<?php echo base_url('assets/livros/'.$e['foto']) ?>" alt="Generic placeholder image">
                            </a>
                            <div class="media-body">
                            <a class="" href="<?php echo site_url("blog/mostra_livro/$id/$url_slug")?>">
                                <h5 class="mt-0 mb-1"><?php echo $e['titulo'] ?></h5>
                            </a>
                                <p class="mt-0 mb-1"><?php echo $e['autor'] ?></p>
                                <p class="mt-0 mb-1"><span class="badge badge-warning"><?php echo $e['preco'] ?></span> </p>
                            </div>
                        </li>
                    <?php endforeach; ?>
                    </ul>                        
                </div>
            </div> 

            <div class="row m-top-10"><?php //3 Livros de medicina ----------------?>
                <div class="card" style="width:100%;">
                    <div class="card-header"> 
                        <h4><i class="fas fa-apple-alt"></i>  Livros de nutrição</h4> 
                    </div>
                    <ul class="list-unstyled m-top-10">
                        <?php foreach($nut as $e) : ?>
                            <li class="media m-bot-10">
                            <?php  $id = $e['id'] ?>
                            <?php  $url_slug = $e['url_slug'] ?>
                            <a class="" href="<?php echo site_url("blog/mostra_livro/$id/$url_slug")?>">
                                <img class="mr-3" src="<?php echo base_url('assets/livros/'.$e['foto']) ?>" alt="Generic placeholder image">
                            </a>    
                            <div class="media-body">
                                <a class="" href="<?php echo site_url("blog/mostra_livro/$id/$url_slug")?>">
                                    <h5 class="mt-0 mb-1"><?php echo $e['titulo'] ?></h5>
                                </a>    
                                <p class="mt-0 mb-1"><?php echo $e['autor'] ?></p>
                                <p class="mt-0 mb-1"><span class="badge badge-warning"><?php echo $e['preco'] ?></span> </p>
                            </div>
                            </li>
                        <?php endforeach; ?>
                    </ul>                        
                </div>
            </div> 

            <div class="row m-top-20"><?php //3 Livros de autoajuda ----------------?>
                <div class="card" style="width:100%;">
                    <div class="card-header"> 
                       <h4><i class="fas fa-hands-helping"></i> Livros de Auto-ajuda</h4> 
                    </div>
                    <ul class="list-unstyled m-top-10">
                    <?php foreach($aut as $e) : ?>
                        <li class="media m-bot-10">
                            <?php  $id = $e['id'] ?>
                            <?php  $url_slug = $e['url_slug'] ?>
                        <a class="" href="<?php echo site_url("blog/mostra_livro/$id/$url_slug")?>">    
                            <img class="mr-3" src="<?php echo base_url('assets/livros/'.$e['foto']) ?>" alt="Generic placeholder image">
                        </a>    
                            <div class="media-body">
                            <a class="" href="<?php echo site_url("blog/mostra_livro/$id/$url_slug")?>">    
                                <h5 class="mt-0 mb-1"><?php echo $e['titulo'] ?></h5>
                            </a>
                                <p class="mt-0 mb-1"><?php echo $e['autor'] ?></p>
                                <p class="mt-0 mb-1"><span class="badge badge-warning"><?php echo $e['preco'] ?></span> </p>
                            </div>
                        </li>
                    <?php endforeach; ?>
                    </ul>                        
                </div>
            </div> 
        </div>  <?php //End Colonna ----------------?>


        <?php //Notizia secondaria -------------------------------------------------------------?>
        <div class="col-sm-4 notizia-secondaria m-bot-20">  
           <!-- Publicita ads -->
            <div class="row m-top-30">
            <script async src="//pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
                <!-- anuncio-home -->
                <ins class="adsbygoogle"
                    style="display:block"
                    data-ad-client="ca-pub-2527299813629802"
                    data-ad-slot="3054334443"
                    data-ad-format="auto"
                    data-full-width-responsive="true"></ins>
                <script>
                (adsbygoogle = window.adsbygoogle || []).push({});
                </script>
            </div>

            <!-- Captura email -->
            <div class="row m-top-30">
                <div class="card text-white bg-warning  " style="width: 100%;">
                    <div class="card-body">
                        <h5 class="card-title" ><i class="fas fa-envelope"></i> Newsletters</h5>
                        <p>Que tal receber algumas noticias de conteúdo personalizadas pra você?</h5>
                        <form action="<?php echo site_url('blog/add_email')?>" method="post">
                            <input type="text" class="form-control" name="text-email"
                            placeholder="Coloque aqui a sua email profissional" required>
                            <button class="btn btn-primary m-top-10" type="submit">Enviar</button>
                        </form>
                    </div>
                </div>  
            </div>
            <!-- Banner della libreria -->
            <div class="row m-top-30">    
                <div class="card" style="width: 100%;">
                    <img class="card-img-top" src="<?php echo base_url('assets/foto/banner_p_livros.jpg')  ?>" alt="Card image cap">
                </div>
            </div>     
            <div class="row m-top-20"><?php //3 Livros de enfermagem ----------------?>
                <div class="card" style="width:100%;">
                    <div class="card-header"> 
                       <h4><i class="fas fa-user-nurse"></i> Top de Enfermagem</h4> 
                    </div>
                    <ul class="list-unstyled m-top-10">
                    <?php foreach($enftre as $e) : ?>
                        <li class="media m-bot-10">
                            <?php  $id = $e['id'] ?>
                            <?php  $url_slug = $e['url_slug'] ?>
                        <a class="" href="<?php echo site_url("blog/mostra_livro/$id/$url_slug")?>">    
                            <img class="mr-3" src="<?php echo base_url('assets/livros/'.$e['foto']) ?>" alt="Generic placeholder image">
                        </a>    
                            <div class="media-body">
                            <a class="" href="<?php echo site_url("blog/mostra_livro/$id/$url_slug")?>">    
                                <h5 class="mt-0 mb-1"><?php echo $e['titulo'] ?></h5>
                            </a>
                                <p class="mt-0 mb-1"><?php echo $e['autor'] ?></p>
                                <p class="mt-0 mb-1"><span class="badge badge-warning"><?php echo $e['preco'] ?></span> </p>
                            </div>
                        </li>
                    <?php endforeach; ?>
                    </ul>                        
                </div>
            </div> 
            <div class="row m-top-20"><?php //3 Livros de lifestyle ----------------?>
                <div class="card" style="width:100%;">
                    <div class="card-header"> 
                       <h4><i class="fas fa-hand-holding-heart"></i> Life-Style</h4> 
                    </div>
                    <ul class="list-unstyled m-top-10">
                    <?php foreach($lifsty as $e) : ?>
                        <li class="media m-bot-10">
                            <?php  $id = $e['id'] ?>
                            <?php  $url_slug = $e['url_slug'] ?>
                        <a class="" href="<?php echo site_url("blog/mostra_livro/$id/$url_slug")?>">    
                            <img class="mr-3" src="<?php echo base_url('assets/livros/'.$e['foto']) ?>" alt="Generic placeholder image">
                        </a>    
                            <div class="media-body">
                            <a class="" href="<?php echo site_url("blog/mostra_livro/$id/$url_slug")?>">    
                                <h5 class="mt-0 mb-1"><?php echo $e['titulo'] ?></h5>
                            </a>
                                <p class="mt-0 mb-1"><?php echo $e['autor'] ?></p>
                                <p class="mt-0 mb-1"><span class="badge badge-warning"><?php echo $e['preco'] ?></span> </p>
                            </div>
                        </li>
                    <?php endforeach; ?>
                    </ul>                        
                </div>
            </div> 
           
        </div><!-- Fine colo 4-->
    </div>
</div>