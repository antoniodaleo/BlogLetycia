<?php
    defined('BASEPATH') OR exit('URL inválido');

    class Pesquisa extends CI_Model{
        
        public function pesquisa_artigo(){
            $titulo = $this->input->post('text-cerca');

            $resultado = $this->db->select('*')
                    ->from('post')
                    ->like('titulo', $titulo)
                    ->get(); 
           
            return $resultado->result_array(); 
        }
        public function pesquisa_livro(){
            $titulo = $this->input->post('text-cerca');

            $resultado = $this->db->select('*')
                    ->from('livros')
                    ->like('titulo', $titulo)
                    ->get(); 
           
            return $resultado->result_array(); 
        }
       
       

    }
?>