<?php
    defined('BASEPATH') OR exit('URL inválido');
?>

<div class="contenitore m-top-20"><!-- Contenitore della notizia e della colonna vicina-->
    <h2 class="tit-principale">Pesquisados</h2>
    
        <div class="colon-7 m-top-10"><!--Colonna sin -->
            <?php foreach($pesq as $e): ?>
            <div id="contenitore-articolo-wrapper">
                <div class="articolo-wrapper "><!--articolo che deve contenere info piu piccole -->
                    <?php  $id = $e['id'] ?>
                    <?php  $url_slug = $e['url_slug'] ?>
                    <a class="a-leia " href="<?php echo site_url("blog/artigo/$id/$url_slug") ?>">
                        <img src="<?php echo base_url('assets/foto/'.$e['foto']) ?>" alt="">  
                    </a>
                </div>
                <div class="descricao-wrapper "><!--Descricao h - p -->
                    <h4><?php echo $e['titulo'] ?></h4>
                    <p class=""> <?php echo $e['descricao'] ?>
                        <a class="a-leia " href="<?php echo site_url("blog/artigo/$id/$url_slug") ?>">
                            <span><em> Leia mais &raquo</em></span> 
                        </a>
                    </p>
                </div>
            </div>
            <?php endforeach; ?>
        </div>

