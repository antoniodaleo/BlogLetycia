<?php
    defined('BASEPATH') OR exit('URL not valid'); 
?>
    

    <nav class="nav-top">
        <ul>
            <li>
                <a href=""></a>
            </li>
            <li>
                <a href="<?php echo site_url('blog/contatos') ?>">Contatos</a>
            </li>
            <li>
                <a href=""></a>
            </li>
        </ul>
    </nav>



