<?php
    defined('BASEPATH') OR exit('URL inválido');    
?>


<div class="container iniziale m-top-20">
    <div class="row m-top-30">

        <?php //Notizia primaria -------------------------------------------------------------- ?>
        <div class="col-sm-3 notizia-primaria m-bot-20">
            
            <?php //1 notizia di medicina --------------- ?>
            <div class="row">  
                <?php foreach($meduno as $m): ?>
                <div class="card">
                    <?php  $id = $m['id'] ?>
                    <?php  $url_slug = $m['url_slug'] ?>
                    <h4 class="card-title"><?php echo $m['categoria'] ?></h4>
                   
                    <a class="" href="<?php echo site_url("blog/artigo/$id/$url_slug")?>">
                        <img class="card-img-top" src="<?php echo base_url('assets/foto/'.$m['foto']) ?>" alt="Card image cap">
                    </a> 
                        <div class="card-body">
                        <a class="" href="<?php echo site_url("blog/artigo/$id/$url_slug")?>">
                            <h5 class="card-title"><?php echo $m['titulo'] ?></h5>
                        </a>
                            <p class="card-text"><?php echo $m['descricao'] ?></p>
                        </div>
                </div>
                <?php endforeach; ?>
            </div>
            
            <?php //1 notizia di enfermagem --------------- ?>
            <div class="row">
                <?php foreach($enfuno as $en): ?>
                <div class="card">
                    <?php  $id = $en['id'] ?>
                    <?php  $url_slug = $en['url_slug'] ?>
                        <h4 class="card-title"><?php echo $en['categoria'] ?></h4>
                        <a class="" href="<?php echo site_url("blog/artigo/$id/$url_slug")?>">
                            <img class="card-img-top" src="<?php echo base_url('assets/foto/'.$en['foto']) ?>" alt="Card image cap">
                        </a>
                        <div class="card-body">
                        <a class="" href="<?php echo site_url("blog/artigo/$id/$url_slug")?>">
                            <h5 class="card-title"><?php echo $en['titulo'] ?></h5>
                        </a>    
                            <p class="card-text"><?php echo $en['descricao'] ?></p>
                        </div>
                </div>
                <?php endforeach; ?>
            </div>
            <?php //1 notizia di psicologia --------------- ?>
            <div class="row">
                <?php foreach($psi as $en): ?>
                <div class="card">
                    <?php  $id = $en['id'] ?>
                    <?php  $url_slug = $en['url_slug'] ?>
                        <h4 class="card-title"><?php echo $en['categoria']?></h4>
                        <a class="" href="<?php echo site_url("blog/artigo/$id/$url_slug")?>">
                            <img class="card-img-top" src="<?php echo base_url('assets/foto/'.$en['foto']) ?>" alt="Card image cap">
                        </a>
                        <div class="card-body">
                        <a class="" href="<?php echo site_url("blog/artigo/$id/$url_slug")?>">
                            <h5 class="card-title"><?php echo $en['titulo'] ?></h5>
                        </a>    
                            <p class="card-text"><?php echo $en['descricao'] ?></p>
                        </div>
                </div>
                <?php endforeach; ?>
            </div>
            <?php //Pubblicita --------------- ?>
            <div class="row">
                <div class="card" style="width:100%;"> 
                    <script async src="//pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
                    <ins class="adsbygoogle"
                        style="display:block"
                        data-ad-format="fluid"
                        data-ad-layout-key="-6o+en+19-2u+p"
                        data-ad-client="ca-pub-2527299813629802"
                        data-ad-slot="2906994785"></ins>
                    <script>
                        (adsbygoogle = window.adsbygoogle || []).push({});
                    </script>
                </div>
            </div>
            <?php //3 notizie di lifestyle ----------------?>
            <div class="row m-top-20 ">     
                <div class="list-group">
                    <span class="badge badge-info">LIFESTYLE</span>
                    <?php foreach($lif as $l): ?>
                    <?php  $id = $l['id'] ?>
                    <?php  $url_slug = $l['url_slug'] ?>
                    <a href="<?php echo site_url("blog/artigo/$id/$url_slug")?>" class="list-group-item list-group-item-action flex-column align-items-start ">
                        <div class="d-flex w-100 justify-content-between">
                            <h5 class="mb-1"><?php echo $l['titulo'] ?></h5>
                        </div>
                        <p class="mb-1"><?php echo $l['descricao'] ?></p>
                        <small><?php echo $l['data_post'] ?></small>
                    </a>
                    <?php endforeach; ?>
                </div>
                
            </div>
        </div>


        <?php //Notizia principale ------------------------------------------------------------?>
        <div class="col-sm-5 notizia-principale m-bot-20">
            <?php //Ultima notizia pubblicata ----------------?>
            <div class="row">      
                <div class="card" style="width:100%;">
                    <?php foreach($news as $n): ?>
                    <?php  $id = $n['id'] ?>
                    <?php  $url_slug = $n['url_slug'] ?>
                    <a class="" href="<?php echo site_url("blog/artigo/$id/$url_slug")?>">
                        <img class="card-img-top" src="<?php echo base_url('assets/foto/'.$n['foto']) ?>" alt="Card image cap">
                    </a>   
                        <div class="card-body">
                            <h4 class="card-title">Ultima noticia</h4>
                            <a class="" href="<?php echo site_url("blog/artigo/$id/$url_slug")?>">
                                <h5 class="card-title"><?php echo $n['titulo'] ?></h5>
                            </a>
                            <p class="card-text"><?php echo $n['descricao'] ?></p>
                        </div>
                    <?php endforeach; ?>
                </div>
            </div>
            <?php //2 notizie di enfermagem ----------------?>
            <div class="row m-top-20">
                <div class="card-deck">
                <?php foreach($enf as $e): ?>
                <?php  $id = $e['id'] ?>
                <?php  $url_slug = $e['url_slug'] ?>
                    <div class="card">
                    <a class="" href="<?php echo site_url("blog/artigo/$id/$url_slug")?>">
                        <img class="card-img-top" src="<?php echo base_url('assets/foto/'.$e['foto']) ?>" alt="Card image cap">
                    </a>    
                        <div class="card-body">
                            <h4 class="card-title"><?php echo $e['categoria']?></h4>
                            <a class="" href="<?php echo site_url("blog/artigo/$id/$url_slug")?>">
                                <h5 class="card-title"><?php echo $e['titulo'] ?></h5>
                            </a>
                            <p class="card-text"><?php echo $e['descricao'] ?></p>
                            <p class="card-text"><small class="text-muted"><?php echo $e['data_post'] ?></small></p>
                        </div>
                    </div>
                <?php endforeach;  ?>
                </div>
            </div>
            <?php //Sezione di nutrizione ----------------?>
            <div class="row m-top-20 ">     
                <div class="list-group">
                    <span class="badge badge-info">NUTRIÇÃO</span>
                    <?php foreach($nut as $n): ?>
                    <?php  $id = $n['id'] ?>
                    <?php  $url_slug = $n['url_slug'] ?>
                    <a href="<?php echo site_url("blog/artigo/$id/$url_slug")?>" class="list-group-item list-group-item-action flex-column align-items-start ">
                        <div class="d-flex w-100 justify-content-between">
                        <h5 class="mb-1"><?php echo $n['titulo'] ?></h5>
                        
                        </div>
                        <p class="mb-1"><?php echo $n['descricao'] ?></p>
                        <small><?php echo $e['data_post'] ?></small>
                    </a>
                    <?php endforeach; ?>
                </div>
            </div>
            <?php //Sezione di medicina ----------------?>
            <div class="row m-top-20">
                <div class="card-deck">
                <?php foreach($med as $m): ?>
                    <div class="card">
                    <a class="" href="<?php echo site_url("blog/artigo/$id/$url_slug")?>">
                        <img class="card-img-top" src="<?php echo base_url('assets/foto/'.$m['foto']) ?>" alt="Card image cap">
                    </a>
                        <div class="card-body">
                            <h4 class="card-title"><?php echo $m['categoria'] ?></h4>
                            <a class="" href="<?php echo site_url("blog/artigo/$id/$url_slug")?>">
                            <h5 class="card-title"><?php echo $m['titulo'] ?></h5>
                            </a>
                            <p class="card-text"><?php echo $m['descricao'] ?></p>
                            <p class="card-text"><small class="text-muted"><?php echo $m['data_post'] ?></small></p>
                        </div>
                    </div>
                <?php endforeach;  ?>
                </div>
            </div>
            <?php //Sezione di lifestyle principale ----------------?>
            <div class="row m-top-20">
                <div class="card" style="width:100%;">
                    <?php foreach($lifuno as $l): ?>
                    <?php  $id = $l['id'] ?>
                    <?php  $url_slug = $l['url_slug'] ?>
                    <a class="" href="<?php echo site_url("blog/artigo/$id/$url_slug")?>">
                        <img class="card-img-top" src="<?php echo base_url('assets/foto/'.$l['foto']) ?>" alt="Card image cap">
                    </a>    
                        <div class="card-body">
                            <h4 class="card-title">LifeStyle</h4>
                            <a class="" href="<?php echo site_url("blog/artigo/$id/$url_slug")?>">
                            <h5 class="card-title"><?php echo $l['titulo'] ?></h5>
                            </a>
                            <p class="card-text"><?php echo $l['descricao'] ?></p>
                        </div>
                    <?php endforeach; ?>
                </div>
            </div>
            <?php //Sezione di panorama ----------------?>
            <div class="row m-top-20">
                <div class="card-deck">
                <?php foreach($pan as $m): ?>
                    <div class="card">
                    <a class="" href="<?php echo site_url("blog/artigo/$id/$url_slug")?>">
                        <img class="card-img-top" src="<?php echo base_url('assets/foto/'.$m['foto']) ?>" alt="Card image cap">
                    </a>
                        <div class="card-body">
                            <h4 class="card-title"><?php echo $m['categoria'] ?></h4>
                            <a class="" href="<?php echo site_url("blog/artigo/$id/$url_slug")?>">
                            <h5 class="card-title"><?php echo $m['titulo'] ?></h5>
                            </a>
                            <p class="card-text"><?php echo $m['descricao'] ?></p>
                            <p class="card-text"><small class="text-muted"><?php echo $m['data_post'] ?></small></p>
                        </div>
                    </div>
                <?php endforeach;  ?>
                </div>
            </div>
            <?php //Pubblicita ----------------?>
            <div class="row m-top-30">
                <div class="card" style="width:100%;"> 
                    <script async src="//pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
                    <ins class="adsbygoogle"
                        style="display:block"
                        data-ad-format="fluid"
                        data-ad-layout-key="-h1+p-1k-cu+tf"
                        data-ad-client="ca-pub-2527299813629802"
                        data-ad-slot="6582160694"></ins>
                    <script>
                        (adsbygoogle = window.adsbygoogle || []).push({});
                    </script>
                </div>
            </div>
        </div>


        <?php //Notizia secondaria -------------------------------------------------------------?>
        <div class="col-sm-4 notizia-secondaria m-bot-20">
            <!-- Video -->
            <div class="row">
                <div class="card" style="width:100%;"> 
                    <?php foreach($vid2 as $v): ?>
                        <h4>TOP VIDEO </h4>
                        <?php  echo $v['frame'];  ?> 
                        <h5><i class="fas fa-video"></i>  <?php  echo $v['titulo'];  ?> </h5>
                    <?php endforeach;?>
                </div>             
            </div>
            <!-- Banner della libreria -->
            <div class="row m-top-30">    
                <div id="carouselExampleSlidesOnly" class="carousel slide" data-ride="carousel">
                    <span class="badge badge-info">VISITA O BOOKSHOP</span>
                    <div class="carousel-inner">
                        <div class="carousel-item active">
                        <a  href="<?php echo site_url('blog/livraria') ?>">
                            <img class="d-block w-100" src="<?php echo base_url('assets/foto/sae_banner.jpg') ?>" alt="First slide">
                        </a>
                        </div>
                        <div class="carousel-item">
                        <a href="<?php echo site_url('blog/livraria') ?>">
                            <img class="d-block w-100" src="<?php echo base_url('assets/foto/livros_banner.jpg') ?>" alt="Second slide">
                        </a>
                        </div>
                    </div>
                </div>
            </div>
               
            <!-- Video -->
            <div class="row m-top-30">
                <div class="card" style="width:100%;"> 
                    <?php foreach($vid as $v): ?>
                        <h4>TOP VIDEO </h4>
                        <?php  echo $v['frame'];  ?> 
                        <h5><i class="fas fa-video"></i>  <?php  echo $v['titulo'];  ?> </h5>
                    <?php endforeach;?>
                </div>             
            </div>  
             <!-- Captura email -->
            <div class="row m-top-30">
                <div class="card text-white bg-warning  " style="width: 100%;">
                    <div class="card-body">
                        <h5 class="card-title" ><i class="fas fa-envelope"></i> Newsletters</h5>
                        <p>Que tal receber algumas noticias de conteúdo personalizadas pra você?</h5>
                        <form action="<?php echo site_url('blog/add_email')?>" method="post">
                            <input type="text" class="form-control" name="text-email"
                            placeholder="Coloque aqui a sua email profissional" required>
                            <button class="btn btn-primary m-top-10" type="submit">Enviar</button>
                            
                        </form>
                    </div>
                </div>  
            </div>
            <!-- Lista di libri-->
            <div class="row m-top-30">
                <div class="card" style="width:100%;">
                    <div class="card-header"> 
                       <h4><i class="fas fa-user-nurse"></i>Livros mais procurados</h4> 
                    </div>
                    <ul class="list-unstyled m-top-10">
                    <?php foreach($livpro as $e) : ?>
                        <li class="media m-bot-10">
                            <?php  $id = $e['id'] ?>
                            <?php  $url_slug = $e['url_slug'] ?>
                        <a class="" href="<?php echo site_url("blog/mostra_livro/$id/$url_slug")?>">    
                            <img class="mr-3" src="<?php echo base_url('assets/livros/'.$e['foto']) ?>" alt="Generic placeholder image">
                        </a>    
                            <div class="media-body">
                            <a class="" href="<?php echo site_url("blog/mostra_livro/$id/$url_slug")?>">    
                                <h5 class="mt-0 mb-1"><?php echo $e['titulo'] ?></h5>
                            </a>
                                <p class="mt-0 mb-1"><?php echo $e['autor'] ?></p>
                                <p class="mt-0 mb-1"><span class="badge badge-warning"><?php echo $e['preco'] ?></span> </p>
                            </div>
                        </li>
                    <?php endforeach; ?>
                    </ul>                        
                </div>   
            </div>
            <!-- Pubblicita adv-->
            <div class="row m-top-30">
                <div class="card" style="width:100%;"> 
                    <script async src="//pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
                    <ins class="adsbygoogle"
                        style="display:block"
                        data-ad-format="fluid"
                        data-ad-layout-key="-h1+p-1k-cu+tf"
                        data-ad-client="ca-pub-2527299813629802"
                        data-ad-slot="6582160694"></ins>
                    <script>
                        (adsbygoogle = window.adsbygoogle || []).push({});
                    </script>
                </div>
            </div>
            <!-- Curtir pagina -->
            <div class="row m-top-30">
                <div class="card" style="width:100%;"> 
                    <div class="fb-page" data-href="https://www.facebook.com/letycialobatofanpage/?modal=admin_todo_tour" data-tabs="timeline" data-width="500" data-height="530" data-small-header="true" data-adapt-container-width="true" data-hide-cover="false" data-show-facepile="true"><blockquote cite="https://www.facebook.com/letycialobatofanpage/?modal=admin_todo_tour" class="fb-xfbml-parse-ignore"><a href="https://www.facebook.com/letycialobatofanpage/?modal=admin_todo_tour">Letycialobato</a></blockquote></div>
                </div>
            </div>
        </div><!-- Fine colo 4-->
    </div>
</div>