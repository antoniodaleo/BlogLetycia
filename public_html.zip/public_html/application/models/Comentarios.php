<?php
    defined('BASEPATH') OR exit('URL inválido');

    class Comentarios extends CI_Model{
        
        public function inserir_comentario(){
            $dados = array(
                'nome' =>$this->input->post('text-nome'),
                'comento' => $this->input->post('text-comentario'),
                'id_post'=> $this->input->post('text-id')
               
            );
            $this->db->insert('comentario', $dados); 
        }
       


        public function pega_comentarios_post($id_post){
            $resultado =$this->db
            ->query('select * from comentario where id_post ='.$id_post.'  order by id desc ');
            return $resultado->result_array(); 
        }

        public function pega_comentarios_post_titulo($tit){
            $resultado =$this->db
            ->query('select * from comentario where titulo ='.$tit.'  order by id desc ');
            return $resultado->result_array(); 
        }
    }
?>